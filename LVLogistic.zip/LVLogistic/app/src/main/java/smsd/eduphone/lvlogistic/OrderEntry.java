package smsd.eduphone.lvlogistic;

public class OrderEntry {
    private String maKH;
    private String md;
    private double can;
    private String maKien;
    private String kyKhoA;
    private String xuatKhoA;
    private String nhapKhoB;
    private String traKhach;

    public OrderEntry(String maKH, String md, double can, String maKien, String kyKhoA,
                      String xuatKhoA, String nhapKhoB, String traKhach) {
        this.maKH = maKH;
        this.md = md;
        this.can = can;
        this.maKien = maKien;
        this.kyKhoA = kyKhoA;
        this.xuatKhoA = xuatKhoA;
        this.nhapKhoB = nhapKhoB;
        this.traKhach = traKhach;
    }

    // Getters and Setters
    public String getMaKH() { return maKH; }
    public void setMaKH(String maKH) { this.maKH = maKH; }
    public String getMd() { return md; }
    public void setMd(String md) { this.md = md; }
    public double getCan() { return can; }
    public void setCan(double can) { this.can = can; }
    public String getMaKien() { return maKien; }
    public void setMaKien(String maKien) { this.maKien = maKien; }
    public String getKyKhoA() { return kyKhoA; }
    public void setKyKhoA(String kyKhoA) { this.kyKhoA = kyKhoA; }
    public String getXuatKhoA() { return xuatKhoA; }
    public void setXuatKhoA(String xuatKhoA) { this.xuatKhoA = xuatKhoA; }
    public String getNhapKhoB() { return nhapKhoB; }
    public void setNhapKhoB(String nhapKhoB) { this.nhapKhoB = nhapKhoB; }
    public String getTraKhach() { return traKhach; }
    public void setTraKhach(String traKhach) { this.traKhach = traKhach; }
}

