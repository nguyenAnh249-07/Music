package smsd.eduphone.lvlogistic;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import smsd.eduphone.lvlogistic.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private static final String URLKEY = "AKfycbydogPtOqL0tkGFk7FVBp6mPQoaLxU6_mIu1OcUy16lmldhw58O-Ey1G6EZvj7iFpVoNA";
    ActivityMainBinding binding;
    private static final int REQUEST_CODE_QR_SCAN_1 = 101;
    private static final int REQUEST_CODE_QR_SCAN_2 = 102;
    private String maKH,maDon,maKien;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        fetchDataFromServer();
        //thêm cấp quyền camera


        binding.btnNhap.setOnClickListener(v -> {
            String _maDon = binding.edtMaDon.getText().toString().trim();
            if(_maDon.isEmpty()){
                Toast.makeText(MainActivity.this, "Vui lòng nhập mã đơn", Toast.LENGTH_SHORT).show();
                return;
            }

            maDon = _maDon;
            binding.tvMaDon.setText("Mã đơn: " + maDon);
        });

        binding.btnNhap2.setOnClickListener(v -> {
            String _maKien = binding.edtMaKien.getText().toString().trim();
            if(_maKien.isEmpty()){
                Toast.makeText(MainActivity.this, "Vui lòng nhập mã kiện", Toast.LENGTH_SHORT).show();
                return;
            }

            maKien = _maKien;
            binding.tvMaKien.setText("Mã kiện: " + maKien);
        });

        binding.btnQuetMa.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, QrCodeActivity.class);
            startActivityForResult(intent, REQUEST_CODE_QR_SCAN_1);
        });

        binding.btnXoa.setOnClickListener(v -> {
            binding.tvMaDon.setText("Mã đơn: ");
            binding.tvMaKien.setText("Mã kiện: ");
            binding.edtMaDon.setText("");
            binding.edtMaKien.setText("");
            maDon = "";
            maKien = "";
        });

        binding.btnQuetMa2.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, QrCodeActivity.class);
            startActivityForResult(intent, REQUEST_CODE_QR_SCAN_2);
        });

        binding.btnXacNhan.setOnClickListener(v -> {
            //https://script.google.com/macros/s/ABCDE12345/exec?action=update&sheet=SheetName&maDon=XXXX&maKien=YYYY&newMaKH=ZZZZ


            if(maKH == null || maDon == null || maKien == null || maKH.isEmpty() || maDon.isEmpty() || maKien.isEmpty()){
                maDon = binding.edtMaDon.getText().toString().trim();
                maKien = binding.edtMaKien.getText().toString().trim();
                if (maKH == null || maDon == null || maKien == null || maKH.isEmpty() || maDon.isEmpty() || maKien.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Vui lòng nhập mã đơn, mã kiện và chọn mã khách hàng", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
            binding.tvKetQua.setText("Đang xử lý...\n"+"Mã KH: " + maKH + " - Mã đơn: " + maDon + " - Mã kiện: " + maKien);
            String url = "https://script.google.com/macros/s/" + URLKEY + "/exec?action=update&sheet=LV&maDon=" + maDon + "&maKien=" + maKien + "&newMaKH=" + maKH;
            RequestQueue queue = Volley.newRequestQueue(this);
            StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            Toast.makeText(MainActivity.this, response, Toast.LENGTH_SHORT).show();
                            Log.d(TAG, "onResponse: " + response);
                            binding.tvKetQua.setText(response);
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e(TAG, "onErrorResponse: ", error);
                }
            });

            queue.add(stringRequest);
        });
    }

    private void fetchDataFromServer() {
        String url = "https://script.google.com/macros/s/" + URLKEY + "/exec?action=read&sheet=KH"; // Update with your URL

        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d(TAG, "onResponse: " + response);
                        Gson gson = new Gson();
                        Type type = new TypeToken<List<KhachHang>>() {
                        }.getType();
                        List<KhachHang> orderEntries = gson.fromJson(response, type);
                        Log.d(TAG, "onResponse: " + orderEntries.size());
                        List<String> khachHangs = new ArrayList<>();
                        for (KhachHang khachHang : orderEntries) {
                            khachHangs.add("Mã KH: " + khachHang.getMaKH() + " - " + khachHang.getTenKH());
                            Log.d(TAG, "onResponse: " + khachHang.getMaKH() + " - " + khachHang.getTenKH());
                        }
                        ArrayAdapter<String> adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, khachHangs);
                        binding.spinner.setAdapter(adapter);
                        if (!orderEntries.isEmpty()) {
                            binding.spinner.setSelection(0);
                            maKH = orderEntries.get(0).getMaKH();
                        }
                        Log.d(TAG, "onResponse: " + orderEntries.size());
                        binding.spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                KhachHang khachHang = orderEntries.get(position);
                                maKH = khachHang.getMaKH();
                                Log.d(TAG, "onItemSelected: " + khachHang.getMaKH() + " - " + khachHang.getTenKH());
                            }
                            @Override
                            public void onNothingSelected(AdapterView<?> parent) {
                            }
                        });
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "onErrorResponse: ", error);
            }
        });

        queue.add(stringRequest);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_QR_SCAN_1 && resultCode == RESULT_OK) {
            if (data != null) {
                String qrCodeValue = data.getStringExtra("SCAN_RESULT");
                // Handle the scanned QR code value
                binding.tvMaDon.setText("Mã đơn: " + qrCodeValue);
                maDon = qrCodeValue;
            }
        }
        if (requestCode == REQUEST_CODE_QR_SCAN_2 && resultCode == RESULT_OK) {
            if (data != null) {
                String qrCodeValue = data.getStringExtra("SCAN_RESULT");
                // Handle the scanned QR code value
                binding.tvMaKien.setText("Mã kiện: " + qrCodeValue);
                maKien = qrCodeValue;
            }
        }
    }

}