package edu.hado.littleboss1.Adapter;

import static edu.hado.littleboss1.Fragment.Fragment_ThanhVien.maTV;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import edu.hado.littleboss1.Fragment.Fragment_ThanhVien;
import edu.hado.littleboss1.Fragment.Fragment_hoaDonThanhVien;
import edu.hado.littleboss1.Model.loaiThuCung;
import edu.hado.littleboss1.Model.thanhVien;
import edu.hado.littleboss1.R;

public class adapterLoadTV extends RecyclerView.Adapter<adapterLoadTV.ViewHolder> {
    Fragment_ThanhVien Fragment_ThanhVien;
    Context context;
    ArrayList<thanhVien> thanhViens;
    public adapterLoadTV(Fragment_ThanhVien Fragment_ThanhVien, ArrayList<thanhVien> thanhViens, Context context) {
        this.Fragment_ThanhVien = Fragment_ThanhVien;
        this.thanhViens = thanhViens;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.item_thanh_vien, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        thanhVien vien = thanhViens.get(position);
        holder.name.setText(vien.getHoTen());
        holder.sdt.setText(vien.getSoDienThoai());
        holder.layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int i = position;
                Fragment fragment = new Fragment();
                Class fragmentClass = Fragment_hoaDonThanhVien.class;
                maTV = thanhViens.get(i).getMaTV();
                try {
                    fragment = (Fragment) fragmentClass.newInstance();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (fragment != null) {
                    FragmentManager fragmentManager =Fragment_ThanhVien.getParentFragmentManager() ;
                    fragmentManager.beginTransaction().setCustomAnimations(android.R.animator.fade_in, android.R.animator.fade_out)
                            .replace(R.id.frameLayout, fragment).commit();
                }
            }
        });
    }

    public void updatedata(List<loaiThuCung> data) {
        data.clear();
        data.addAll(data);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return thanhViens.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name,sdt;
        RelativeLayout layout;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.name);
            sdt = itemView.findViewById(R.id.sdt);
            layout = itemView.findViewById(R.id.clicktv);
        }
    }
}
