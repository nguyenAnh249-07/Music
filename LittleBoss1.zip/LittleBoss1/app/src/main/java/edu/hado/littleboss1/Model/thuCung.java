package edu.hado.littleboss1.Model;

import java.io.Serializable;

public class thuCung implements Serializable {
    private String TenThuCung,MaThuCung,MaLoaiThuCung,GioiTinh,NgaySinh,GiongLoai,MoTa,Hinh,Gia;;
    private int  SoLuong;

    public thuCung(String tenThuCung, String maThuCung, String maLoaiThuCung, String gioiTinh, String ngaySinh, String giongLoai, String moTa, String hinh, String gia, int soLuong) {
        TenThuCung = tenThuCung;
        MaThuCung = maThuCung;
        MaLoaiThuCung = maLoaiThuCung;
        GioiTinh = gioiTinh;
        NgaySinh = ngaySinh;
        GiongLoai = giongLoai;
        MoTa = moTa;
        Hinh = hinh;
        Gia = gia;
        SoLuong = soLuong;
    }

    public thuCung() {
    }

    public String getTenThuCung() {
        return TenThuCung;
    }

    public void setTenThuCung(String tenThuCung) {
        TenThuCung = tenThuCung;
    }

    public String getMaThuCung() {
        return MaThuCung;
    }

    public void setMaThuCung(String maThuCung) {
        MaThuCung = maThuCung;
    }

    public String getMaLoaiThuCung() {
        return MaLoaiThuCung;
    }

    public void setMaLoaiThuCung(String maLoaiThuCung) {
        MaLoaiThuCung = maLoaiThuCung;
    }

    public String getGioiTinh() {
        return GioiTinh;
    }

    public void setGioiTinh(String gioiTinh) {
        GioiTinh = gioiTinh;
    }

    public String getNgaySinh() {
        return NgaySinh;
    }

    public void setNgaySinh(String ngaySinh) {
        NgaySinh = ngaySinh;
    }

    public String getGiongLoai() {
        return GiongLoai;
    }

    public void setGiongLoai(String giongLoai) {
        GiongLoai = giongLoai;
    }

    public String getMoTa() {
        return MoTa;
    }

    public void setMoTa(String moTa) {
        MoTa = moTa;
    }

    public String getHinh() {
        return Hinh;
    }

    public void setHinh(String hinh) {
        Hinh = hinh;
    }

    public String getGia() {
        return Gia;
    }

    public void setGia(String gia) {
        Gia = gia;
    }

    public int getSoLuong() {
        return SoLuong;
    }

    public void setSoLuong(int soLuong) {
        SoLuong = soLuong;
    }
}
