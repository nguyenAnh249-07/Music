package edu.hado.littleboss1.Model;

import android.app.Application;
import android.text.format.DateFormat;

import java.util.Calendar;
import java.util.Locale;

public class fromattime extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
    }
    public static final String fromatTime(long time) {
        Calendar calendar = Calendar.getInstance(Locale.getDefault());
        calendar.setTimeInMillis(time);

        String date = DateFormat.format("dd/MM/yyyy HH:mm",calendar).toString();

        return date;
    }
}
