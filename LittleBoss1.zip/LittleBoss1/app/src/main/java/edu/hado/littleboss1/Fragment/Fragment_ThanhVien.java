package edu.hado.littleboss1.Fragment;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import cn.pedant.SweetAlert.SweetAlertDialog;
import edu.hado.littleboss1.Activity.MainActivity;
import edu.hado.littleboss1.Adapter.adapterFirebaseTV;
import edu.hado.littleboss1.Adapter.adapterLoadTV;
import edu.hado.littleboss1.Model.thanhVien;
import edu.hado.littleboss1.R;

public class Fragment_ThanhVien extends Fragment {

    private RecyclerView recyclerView;
    private SearchView searchText;
    private Class fragmentClass;
    private ArrayList<thanhVien> thanhviens = new ArrayList<>();
    private MainActivity activity;
    public static Fragment fragment;
    SweetAlertDialog pDialog;
    private adapterLoadTV adapterloadTV;
    public static String maTV;
    public Fragment_ThanhVien() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment__thanh_vien, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = view.findViewById(R.id.rc_thucung);
        searchText = view.findViewById(R.id.searchEdt);
        searchText = view.findViewById(R.id.searchEdt);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager llm = new LinearLayoutManager(requireActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(llm);
        activity = (MainActivity) getActivity();
        showProgress();
        loadtv();
        searchText.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                progresssearch(query);
//                progresssearchten(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                progresssearch(newText);
//                progresssearchten(newText);
                return false;
            }
        });
    }

    //search
    private void progresssearch(String s) {
        adapterFirebaseTV adapterFirebase;
        FirebaseRecyclerOptions<thanhVien> options =
                new FirebaseRecyclerOptions.Builder<thanhVien>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("ThanhVien").orderByChild("soDienThoai").startAt(s).endAt(s+"\uf8ff"), thanhVien.class)
                        .build();
        System.out.println(options);
        adapterFirebase = new adapterFirebaseTV(options,Fragment_ThanhVien.this, thanhviens);
        adapterFirebase.startListening();
        recyclerView.setAdapter(adapterFirebase);
    }
//    //search
//    private void progresssearchten(String s) {
//        adapterFirebaseTV adapterFirebase;
//        FirebaseRecyclerOptions<thanhVien> options =
//                new FirebaseRecyclerOptions.Builder<thanhVien>()
//                        .setQuery(FirebaseDatabase.getInstance().getReference().child("ThanhVien").orderByChild("hoTen").startAt(s).endAt(s+"\uf8ff"), thanhVien.class)
//                        .build();
//        System.out.println(options);
//        adapterFirebase = new adapterFirebaseTV(options,Fragment_ThanhVien.this, thanhviens);
//        adapterFirebase.startListening();
//        recyclerView.setAdapter(adapterFirebase);
//    }

    //progress
    private void showProgress(){
        pDialog = new SweetAlertDialog(requireContext(), SweetAlertDialog.PROGRESS_TYPE);
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#A5DC86"));
        pDialog.setTitleText("Loading");
        pDialog.setCancelable(false);
        pDialog.show();
    }
    //loadtv
    private void loadtv() {
        DatabaseReference reference;
        reference = FirebaseDatabase.getInstance().getReference("ThanhVien");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                thanhviens.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    thanhVien thuCung = dataSnapshot.getValue(thanhVien.class);
                    thanhviens.add(thuCung);
                    System.out.println(thanhviens.size());
                }
                adapterloadTV = new adapterLoadTV(Fragment_ThanhVien.this, thanhviens,activity);
                recyclerView.setAdapter(adapterloadTV);
                pDialog.dismissWithAnimation();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}