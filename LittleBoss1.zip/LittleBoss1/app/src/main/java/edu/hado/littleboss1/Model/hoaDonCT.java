package edu.hado.littleboss1.Model;

public class hoaDonCT {
    private String ten,gia,hinh;
    private int sl;


    public hoaDonCT(String ten, String gia, int sl) {
        this.ten = ten;
        this.gia = gia;
        this.sl = sl;
    }

    public hoaDonCT(String ten, String gia, String hinh, int sl) {
        this.ten = ten;
        this.gia = gia;
        this.hinh = hinh;
        this.sl = sl;
    }

    public hoaDonCT() {
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public String getGia() {
        return gia;
    }

    public void setGia(String gia) {
        this.gia = gia;
    }

    public int getSl() {
        return sl;
    }

    public void setSl(int sl) {
        this.sl = sl;
    }

    public String getHinh() {
        return hinh;
    }

    public void setHinh(String hinh) {
        this.hinh = hinh;
    }
}
