package edu.hado.littleboss1.Fragment;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.flatdialoglibrary.dialog.FlatDialog;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.melnykov.fab.FloatingActionButton;

import java.util.ArrayList;

import cn.pedant.SweetAlert.SweetAlertDialog;
import edu.hado.littleboss1.Activity.MainActivity;
import edu.hado.littleboss1.Adapter.adapterLoadTL;
import edu.hado.littleboss1.Model.loaiThuCung;
import edu.hado.littleboss1.R;

public class Fragment_LoaiThu extends Fragment {

    private RecyclerView recyclerView;
    private FloatingActionButton tab;
    private ArrayList<loaiThuCung> loaiThuCungs = new ArrayList<>();
    private adapterLoadTL loadtl;
    private MainActivity activity;
    SweetAlertDialog pDialog;
    public Fragment_LoaiThu() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment__loai_thu, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = view.findViewById(R.id.rc_loaithu);
        tab = view.findViewById(R.id.fab_loaithu);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        activity = (MainActivity) getActivity();
        tab.attachToRecyclerView(recyclerView);
        tab.setOnClickListener(this::onClickThemLoaiThu);
        showProgress();
        loadTl();
    }
    // thêm loại thú cưng
    private void onClickThemLoaiThu(View view) {
        final FlatDialog flatDialog = new FlatDialog(requireContext());
        FirebaseDatabase rootNode = FirebaseDatabase.getInstance();
        DatabaseReference reference = rootNode.getReference("LoaiThuCung");
        flatDialog.setTitle("Loại thú cưng")
                .setSubtitle("Hãy nhập vào loại thú cưng mà bạn muốn...")
                .setFirstTextFieldHint("Nhập loại thú cưng")
                .setFirstButtonText("Xác Nhận")
                .setSecondButtonText("Hủy")
                .setFirstButtonColor(Color.parseColor("#E26E43"))
                .setBackgroundColor(Color.WHITE)
                .setTitleColor(Color.BLACK)
                .setFirstTextFieldBorderColor(Color.BLACK)
                .setFirstTextFieldBorderColor(Color.BLACK)
                .setSubtitleColor(Color.BLACK)
                .setFirstTextFieldTextColor(Color.BLACK)
                .withFirstButtonListner(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String loai = flatDialog.getFirstTextField();
                        if(loai.length() == 0){
                            Toast.makeText(activity,"Chưa nhập loại thú",Toast.LENGTH_SHORT).show();
                            return;
                        }
                        reference.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                loaiThuCung thuCung = null;
                                ArrayList<loaiThuCung> thuCungs = new ArrayList<>();
                                for (DataSnapshot child : dataSnapshot.getChildren()) {
                                    thuCung = dataSnapshot.child(child.getKey()).getValue(loaiThuCung.class);
                                    thuCungs.add(thuCung);
                                }
                                int a = thuCungs.size();
                                System.out.println(a);
                                if (a != 0) {
                                    for (int i = 0; i < thuCungs.size(); i++) {
                                        if (loai.equalsIgnoreCase(thuCungs.get(i).getLoaiThuCung())) {
                                            Toast.makeText(requireContext(), "Đã có trong danh sách loại thú cưng", Toast.LENGTH_LONG).show();
                                            loadTl();
                                            return;
                                        }
                                    }
                                }
                                String ma = reference.push().getKey();
                                loaiThuCung thuCung1 = new loaiThuCung(loai, ma);
                                reference.child(ma).setValue(thuCung1);
                           }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });

                        flatDialog.dismiss();
                    }
                })
                .withSecondButtonListner(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        flatDialog.dismiss();
                    }
                })
                .show();
    }
    //progress
    private void showProgress(){
        pDialog = new SweetAlertDialog(requireContext(), SweetAlertDialog.PROGRESS_TYPE);
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#A5DC86"));
        pDialog.setTitleText("Loading");
        pDialog.setCancelable(false);

        pDialog.show();
    }
    // load loại thú cưng
    private void loadTl(){
        DatabaseReference reference;
        reference = FirebaseDatabase.getInstance().getReference("LoaiThuCung");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                loaiThuCungs.clear();
                for (DataSnapshot dataSnapshot:snapshot.getChildren() ){
                    loaiThuCung thuCung = dataSnapshot.getValue(loaiThuCung.class);
                    loaiThuCungs.add(thuCung);
                    System.out.println(loaiThuCungs.size());
                }
                loadtl = new adapterLoadTL(Fragment_LoaiThu.this,loaiThuCungs);
                recyclerView.setAdapter(loadtl);
                pDialog.dismissWithAnimation();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}