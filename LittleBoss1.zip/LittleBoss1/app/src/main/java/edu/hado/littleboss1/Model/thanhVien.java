package edu.hado.littleboss1.Model;

public class thanhVien {
    private String maTV,hoTen;
    private String soDienThoai;

    public thanhVien(String maTV, String hoTen, String soDienThoai) {
        this.maTV = maTV;
        this.hoTen = hoTen;
        this.soDienThoai = soDienThoai;
    }

    public thanhVien() {
    }

    public String getMaTV() {
        return maTV;
    }

    public void setMaTV(String maTV) {
        this.maTV = maTV;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getSoDienThoai() {
        return soDienThoai;
    }

    public void setSoDienThoai(String soDienThoai) {
        this.soDienThoai = soDienThoai;
    }
}
