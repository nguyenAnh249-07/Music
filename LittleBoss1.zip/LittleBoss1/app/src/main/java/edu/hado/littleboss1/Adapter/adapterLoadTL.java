package edu.hado.littleboss1.Adapter;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import cn.pedant.SweetAlert.SweetAlertDialog;
import edu.hado.littleboss1.Fragment.Fragment_LoaiThu;
import edu.hado.littleboss1.Model.loaiThuCung;
import edu.hado.littleboss1.Model.thuCung;
import edu.hado.littleboss1.R;

public class adapterLoadTL extends RecyclerView.Adapter<adapterLoadTL.ViewHolder> {
    Fragment_LoaiThu context;
    ArrayList<loaiThuCung> loaiThuCungs;
    loaiThuCung thuCung;
    edu.hado.littleboss1.Model.thuCung mthuCung;
    ArrayList<thuCung> thuCungs;
    boolean isDelete = false;
    public adapterLoadTL(Fragment_LoaiThu context, ArrayList<loaiThuCung> loaiThuCungs) {
        this.context = context;
        this.loaiThuCungs = loaiThuCungs;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context.requireContext()).inflate(R.layout.item_loai_thu_cung, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView")final int position) {
        thuCung = loaiThuCungs.get(position);

        holder.name.setText(thuCung.getLoaiThuCung());
        holder.layoutDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String aa = loaiThuCungs.get(position).getMaThuCung();
                thuCungs = new ArrayList<>();
                FirebaseDatabase rootNode1 = FirebaseDatabase.getInstance();
                DatabaseReference reference1 = rootNode1.getReference("ThuCung");
                reference1.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        thuCungs.clear();
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            thuCung thuCung = dataSnapshot.getValue(thuCung.class);
                            thuCungs.add(thuCung);
                            System.out.println(thuCungs.size());
                        }
                        for (thuCung x : thuCungs
                        ) {
                            if (loaiThuCungs.get(position).getMaThuCung().equals(x.getMaLoaiThuCung())) {
                                isDelete = true;
                                new SweetAlertDialog(context.requireContext(), SweetAlertDialog.WARNING_TYPE)
                                        .setTitleText("Hiện đang có sản phẩm không thể xóa!!")
                                        .setConfirmButton("Vâng <3", SweetAlertDialog::dismissWithAnimation)
                                        .show();
                                isDelete = false;
                                return;
                            }
                        }
                        if (isDelete) {
                            return;
                        } else {
                            new SweetAlertDialog(context.requireContext(), SweetAlertDialog.WARNING_TYPE)
                                    .setTitleText("Bạn chắc chứ?")
                                    .setContentText("Sẽ không thể khôi phục dữ liệu này!")
                                    .setConfirmButton("Có,tôi muốn xóa nó!", sweetAlertDialog -> {
                                        FirebaseDatabase.getInstance().getReference().child("LoaiThuCung").child(aa).removeValue()
                                                .addOnCompleteListener(command -> sweetAlertDialog.dismiss());
                                    })
                                    .setCancelButton("Không,tôi nghĩ lại rồi:>", SweetAlertDialog::dismiss)
                                    .show();
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

            }
        });
    }

    public void updatedata(List<loaiThuCung> data) {
        data.clear();
        data.addAll(data);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return loaiThuCungs.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name;
        LinearLayout layoutDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.tv_ltc);
            layoutDelete = itemView.findViewById(R.id.layout_delete);
        }
    }
}
