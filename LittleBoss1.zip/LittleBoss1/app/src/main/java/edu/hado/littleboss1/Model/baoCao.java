package edu.hado.littleboss1.Model;

public class baoCao {
    private String date;
    private String tongTien;


    public baoCao(String date, String tongTien) {
        this.date = date;
        this.tongTien = tongTien;
    }

    public baoCao() {
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTongTien() {
        return tongTien;
    }

    public void setTongTien(String tongTien) {
        this.tongTien = tongTien;
    }
}
