package edu.hado.littleboss1.Fragment;

import static android.app.Activity.RESULT_OK;
import static edu.hado.littleboss1.Adapter.adapterFirebasePK.nphukien;
import static edu.hado.littleboss1.Adapter.adapterLoadPK.n2phukien;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import org.angmarch.views.NiceSpinner;
import org.angmarch.views.OnSpinnerItemSelectedListener;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import cn.pedant.SweetAlert.SweetAlertDialog;
import edu.hado.littleboss1.Model.CustomFormat;
import edu.hado.littleboss1.Model.loaiThuCung;
import edu.hado.littleboss1.Model.phuKien;
import edu.hado.littleboss1.R;

public class Fragment_TTPK extends Fragment {
    private Button confirm, cancel;
    private TextInputLayout name, quantity, price, description;
    private NiceSpinner spinner;
    private ImageView image;
    private Button edit, delete, addimg;
    private ProgressBar progressBar;
    private Boolean click = false;
    private ArrayList<phuKien> phuKiens;
    private ArrayList<loaiThuCung> loaiThuCungs;
    private Boolean spinerClick = false;
    private CustomFormat customFormat;
    private Uri imageUri = null;
    private String im;
    private int item;
    private FirebaseDatabase rootNode;
    private DatabaseReference reference;
    private String id;
    private phuKien mphuKien;
    SweetAlertDialog pDialog;
    private boolean checkimg = false;
    private static int fag;

    public Fragment_TTPK() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment__t_t_p_k, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        confirm = view.findViewById(R.id.add_confirm);
        cancel = view.findViewById(R.id.add_cancel);
        name = view.findViewById(R.id.edt_name);
        quantity = view.findViewById(R.id.edt_quantity);
        price = view.findViewById(R.id.edt_price);
        description = view.findViewById(R.id.edt_description);
        spinner = view.findViewById(R.id.nice_spinner);
        image = view.findViewById(R.id.imview);
        delete = view.findViewById(R.id.btn_xoaTC);
        edit = view.findViewById(R.id.btn_suaTC);
        progressBar = view.findViewById(R.id.progress);
        addimg = view.findViewById(R.id.addimg);
        price.getEditText().addTextChangedListener(customFormat= new CustomFormat(price));
        progressBar.setVisibility(View.GONE);
        delete.setOnClickListener(this::onClickDelete);
        edit.setOnClickListener(this::onClickEdit);
        cancel.setOnClickListener(this::onClickCancel);
        confirm.setOnClickListener(this::onClickConfirm);
        addimg.setOnClickListener(this::onImageClick);
        rootNode = FirebaseDatabase.getInstance();
        spinner.setOnClickListener(this::onClickSpinner);
        reference = rootNode.getReference("PhuKien");
        loaiThuCungs = new ArrayList<>();
        switch (fag) {
            case 1: {
                mphuKien = nphukien;
                break;
            }
            case 2: {
                mphuKien = n2phukien;
                break;
            }
        }
        id = mphuKien.getMaPhuKien();
        loadTl();
        fillData();
    }

    private void onClickSpinner(View view) {
        spinerClick = true;
    }

    public static int flag(int a) {
        fag = a;
        return fag;
    }

    private void onClickConfirm(View view) {
        //validate
        if (!validatename() | !validatePrice() | !validateQuantity()) {
            return;
        }
        if(!spinerClick){
            new SweetAlertDialog(requireContext(), SweetAlertDialog.WARNING_TYPE)
                    .setTitleText("Hình như bạn chưa sửa loại thú cưng hãy kiểm tra kĩ một lần nữa")
                    .show();
            spinerClick = false;
            return;
        }
        showProgress();
        String _name = name.getEditText().getText().toString().trim();
        String _quantity = quantity.getEditText().getText().toString().trim();
        String _price = price.getEditText().getText().toString().trim();
        String _description = description.getEditText().getText().toString().trim();
        String ma = loaiThuCungs.get(item).getMaThuCung();
//        if(checkimg){
//            uploadimg();
//            checkimg = false;
//        }
        if (im == null) {
            im = mphuKien.getHinh();
        }
        phuKien pk = new phuKien(id, ma, _name, im, _description, _price, Integer.parseInt(_quantity));
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put(id, pk);
        reference.updateChildren(hashMap).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                pDialog.dismissWithAnimation();
                Toast.makeText(requireContext(), "Cập nhật thành công", Toast.LENGTH_SHORT).show();
                callFragment();
            }
        });

    }
    //showprogress
    private void showProgress(){
        pDialog = new SweetAlertDialog(requireContext(), SweetAlertDialog.PROGRESS_TYPE);
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#A5DC86"));
        pDialog.setCancelable(false);
        pDialog.setTitleText("Đang tải dữ liệu lên...");
        pDialog.show();
    }
    //onclick image
    private void onImageClick(View view) {
        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
        pick.setType("image/*");
//        Intent pho = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        Intent chosser = Intent.createChooser(pick, "chon");
//        chosser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{pho});
        startActivityForResult(chosser, 999);
    }

    //
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 999 && resultCode == RESULT_OK) {
            if (data.getExtras() != null) {
                Bitmap bitmap = (Bitmap) data.getExtras().get("data");
                image.setImageBitmap(bitmap);
                imageUri = data.getData();
                uploadimg();
                System.out.println(imageUri);
                mphuKien.setHinh(String.valueOf(imageUri));

            } else {
                imageUri = data.getData();
                uploadimg();
                mphuKien.setHinh(String.valueOf(imageUri));
                try {
                    InputStream inputStream = requireActivity().getContentResolver().openInputStream(imageUri);
                    imageUri = Uri.parse(inputStream.toString());
                    System.out.println(imageUri);
                    Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                    image.setImageBitmap(bitmap);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    //uploadimg
    private void uploadimg() {
        showProgress();
        pDialog.setTitleText("Đang tải hình ảnh ...");
        String filepath = "ImagePet/" + id;
        StorageReference storageReference = FirebaseStorage.getInstance().getReference(filepath);
        storageReference.putFile(imageUri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        Log.d("Upload", "onSuccess");
                        Task<Uri> uriTask = taskSnapshot.getStorage().getDownloadUrl();
                        while (!uriTask.isSuccessful()) ;
                        String uploadimg = "" + uriTask.getResult();
//                        updateimg(uploadimg);
                        im = uploadimg;
                        pDialog.dismissWithAnimation();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                });
    }

    private void onClickCancel(View view) {
        // Create a storage reference from our app
        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference storageRef = storage.getReference();

// Create a reference to the file to delete
        StorageReference desertRef = storageRef.child("ImagePK/"+id);

// Delete the file
        desertRef.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                // File deleted successfully
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                // Uh-oh, an error occurred!
            }
        });
        callFragment();
    }

    private void onClickDelete(View view) {
        DatabaseReference reference;
        reference = FirebaseDatabase.getInstance().getReference("PhuKien");
        new SweetAlertDialog(requireContext(), SweetAlertDialog.WARNING_TYPE)
                .setTitleText("Bạn chắc chứ?")
                .setContentText("Sẽ không thể khôi phục dữ liệu này!")
                .setConfirmButton("Có,tôi muốn xóa nó!", sweetAlertDialog -> {
                    reference.child(mphuKien.getMaPhuKien()).removeValue()
                            .addOnCompleteListener(command -> sweetAlertDialog.dismiss())
                            .addOnCompleteListener(command -> callFragment())
                            .addOnCompleteListener(command -> Toast.makeText(requireContext(), "Xóa Thành Công", Toast.LENGTH_SHORT).show());

                })
                .setCancelButton("Không,tôi nghĩ lại rồi:>", SweetAlertDialog::dismiss)
                .show();
    }

    private void callFragment() {
        Fragment fragment = new Fragment();
        Class fragmentClass = Fragment_PhuKien.class;
        try {
            fragment = (Fragment) fragmentClass.newInstance();

        } catch (Exception e) {
            e.printStackTrace();
        }
        if (fragment != null) {
            FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();
            fragmentManager.beginTransaction().setCustomAnimations(android.R.animator.fade_in, android.R.animator.fade_out)
                    .replace(R.id.frameLayout, fragment).commit();
        }
    }

    private void onClickEdit(View view) {
        click = true;
        loadTl();
        progressBar.setVisibility(View.VISIBLE);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                name.setEnabled(true);
                quantity.setEnabled(true);
                price.setEnabled(true);
                description.setEnabled(true);
                spinner.setEnabled(true);
                image.setVisibility(View.VISIBLE);
                confirm.setVisibility(View.VISIBLE);
                progressBar.setVisibility(View.GONE);
                addimg.setVisibility(View.VISIBLE);
            }
        }, 2000);
    }

    private void fillData() {
        name.setEnabled(false);
        name.getEditText().setText(mphuKien.getTenPhuKien());
        quantity.getEditText().setText(mphuKien.getSoluong() + "");
        quantity.setEnabled(false);
        price.getEditText().setText("" + mphuKien.getGia());
        price.setEnabled(false);
        description.getEditText().setText(mphuKien.getMoTa());
        description.setEnabled(false);
        spinner.setEnabled(false);
        if(mphuKien.getHinh() == null){
            image.setImageResource(R.drawable.addimg);
        }
        else{
            Glide.with(requireContext()).load(mphuKien.getHinh()).into(image);
        }
        confirm.setVisibility(View.GONE);
        addimg.setVisibility(View.GONE);
    }


    //load loại thú cưng
    private void loadTl() {
        DatabaseReference reference;
        reference = FirebaseDatabase.getInstance().getReference("LoaiThuCung");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                loaiThuCungs.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    loaiThuCung thuCung = dataSnapshot.getValue(loaiThuCung.class);
                    loaiThuCungs.add(thuCung);
                    System.out.println(loaiThuCungs.size());
                }
                if (click) {
                    List<String> dataset = new ArrayList<>();
                    for (int i = 0; i < loaiThuCungs.size(); i++) {
                        System.out.println(loaiThuCungs.get(i).getMaThuCung());
                        dataset.add(loaiThuCungs.get(i).getLoaiThuCung());
                    }
                    spinner.attachDataSource(dataset);
                    spinner.setOnSpinnerItemSelectedListener(new OnSpinnerItemSelectedListener() {
                        @Override
                        public void onItemSelected(NiceSpinner parent, View view, int position, long id) {
                            // This example uses String, but your type can be any
                            item = position;
                        }
                    });
                } else {
                    for (int i = 0; i < loaiThuCungs.size(); i++) {
                        if (loaiThuCungs.get(i).getMaThuCung().equals(mphuKien.getMaLoaiThuCung())) {
                            spinner.setText(loaiThuCungs.get(i).getLoaiThuCung());
                            return;
                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    //validate

    private boolean validatename() {
        String _name = name.getEditText().getText().toString().trim();
        if (_name.isEmpty()) {
            name.setError("Không được bỏ trống!");
            name.requestFocus();
            return false;
        } else if (_name.length() > 30) {
            name.setError(("Tên quá dài!"));
            return false;
        } else {
            name.setError(null);
            name.setErrorEnabled(false);
            return true;
        }
    }


    private boolean validateQuantity() {
        String _quantity = quantity.getEditText().getText().toString().trim();
        if (_quantity.isEmpty()) {
            quantity.setError("Không được bỏ trống!");
            quantity.requestFocus();
            return false;
        } else if (_quantity.length() > 8) {
            price.setError("Số quá lớn!");
            return false;
        } else
            quantity.setError(null);
        quantity.setErrorEnabled(false);
        return true;
    }

    private boolean validatePrice() {
        String _price = price.getEditText().getText().toString().trim();
        if (_price.isEmpty()) {
            price.setError("Không được bỏ trống!");
            price.requestFocus();
            return false;
        } else if (_price.length() > 18) {
            price.setError("Số quá lớn!");
            return false;
        } else
            price.setError(null);
        price.setErrorEnabled(false);
        return true;
    }
}