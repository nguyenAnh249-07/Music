package edu.hado.littleboss1.Interface;

import edu.hado.littleboss1.Model.thuCung;

public interface OnTextClickListener {
    void onTextClick(thuCung data);
}
