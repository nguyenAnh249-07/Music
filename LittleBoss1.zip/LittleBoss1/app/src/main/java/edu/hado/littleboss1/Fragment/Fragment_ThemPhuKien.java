package edu.hado.littleboss1.Fragment;

import static android.app.Activity.RESULT_OK;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import org.angmarch.views.NiceSpinner;
import org.angmarch.views.OnSpinnerItemSelectedListener;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import cn.pedant.SweetAlert.SweetAlertDialog;
import edu.hado.littleboss1.Model.CustomFormat;
import edu.hado.littleboss1.Model.loaiThuCung;
import edu.hado.littleboss1.Model.phuKien;
import edu.hado.littleboss1.R;

public class Fragment_ThemPhuKien extends Fragment {
    private Class fragmentClass;
    public static Fragment fragment;
    private Button confirm, cancel;
    private TextInputLayout name, species, quantity, price, description;
    private NiceSpinner spinner;
    private ImageView image;
    private phuKien mphuKien = new phuKien();
    private ArrayList<phuKien> phuKiens = new ArrayList<>();
    private CustomFormat customFormat;
    private ArrayList<loaiThuCung> loaiThuCungs;
    Uri imageUri = null;
    private String im;
    int item;
    FirebaseDatabase rootNode;
    DatabaseReference reference;
    SweetAlertDialog pDialog;
    private String id;
    public Fragment_ThemPhuKien() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment__them_phu_kien, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        confirm = view.findViewById(R.id.add_confirm);
        cancel = view.findViewById(R.id.add_cancel);
        name = view.findViewById(R.id.edt_name);
        species = view.findViewById(R.id.edt_species);
        quantity = view.findViewById(R.id.edt_quantity);
        price = view.findViewById(R.id.edt_price);
        description = view.findViewById(R.id.edt_description);
        spinner = view.findViewById(R.id.nice_spinner);
        image = view.findViewById(R.id.imview);
        price.getEditText().addTextChangedListener(customFormat = new CustomFormat(price));
        loaiThuCungs = new ArrayList<>();
        loadTl();
        rootNode = FirebaseDatabase.getInstance();
        reference = rootNode.getReference("PhuKien");
        id = reference.push().getKey();
        cancel.setOnClickListener(this::onCancelClick);
        confirm.setOnClickListener(this::onConfirmClick);
        image.setOnClickListener(this::onImageClick);
    }
    private void onConfirmClick(View view) {

        //validate
        if(!validatename() | !validatePrice()  |!validateQuantity()){
            return;
        }
        String _name = name.getEditText().getText().toString().trim();
        String _quantity = quantity.getEditText().getText().toString().trim();
        String _price = price.getEditText().getText().toString().trim();
        String _description = description.getEditText().getText().toString().trim();

        String ma = loaiThuCungs.get(item).getMaThuCung();
        phuKien pk = new phuKien(id,ma,_name,im,_description,_price,Integer.parseInt(_quantity));
        reference.child(id).setValue(pk);
        callFragment();
    }

    //onclick image
    private void onImageClick(View view) {
        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
        pick.setType("image/*");
//        Intent pho = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        Intent chosser = Intent.createChooser(pick, "chon");
        startActivityForResult(chosser, 999);
    }
    //
    //progress
    private void showProgress(){
        pDialog = new SweetAlertDialog(requireContext(), SweetAlertDialog.PROGRESS_TYPE);
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#A5DC86"));
        pDialog.setTitleText("Loading");
        pDialog.setCancelable(false);
        pDialog.show();
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 999 && resultCode == RESULT_OK) {
            if (data.getExtras() != null) {

                Bitmap bitmap = (Bitmap) data.getExtras().get("data");
                image.setImageBitmap(bitmap);
                imageUri = data.getData();
                uploadimg();
                System.out.println(imageUri);
                mphuKien.setHinh(String.valueOf(imageUri));

            } else {
                imageUri = data.getData();
                uploadimg();
                mphuKien.setHinh(String.valueOf(imageUri));
                try {
                    InputStream inputStream = requireActivity().getContentResolver().openInputStream(imageUri);
                    imageUri = Uri.parse(inputStream.toString());

                    System.out.println(imageUri);
                    Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                    image.setImageBitmap(bitmap);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    private void uploadimg(){
        showProgress();
        pDialog.setTitleText("Đang tải hình ảnh...");
        String filepath = "ImagePK/"+id;
        StorageReference storageReference = FirebaseStorage.getInstance().getReference(filepath);
        storageReference.putFile(imageUri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        Log.d("Upload","onSuccess");
                        Task<Uri> uriTask = taskSnapshot.getStorage().getDownloadUrl();
                        while (!uriTask.isSuccessful());
                        String uploadimg = ""+uriTask.getResult();
//                        updateimg(uploadimg);
                        im = uploadimg;
                        pDialog.dismissWithAnimation();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                });
    }
    private void callFragment() {
        Fragment fragment = new Fragment();
        Class fragmentClass = Fragment_PhuKien.class;
        try {
            fragment = (Fragment) fragmentClass.newInstance();

        } catch (Exception e) {
            e.printStackTrace();
        }
        if (fragment != null) {
            FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();
            fragmentManager.beginTransaction().setCustomAnimations(android.R.animator.fade_in, android.R.animator.fade_out)
                    .replace(R.id.frameLayout, fragment).commit();
        }
    }
    private void onCancelClick(View view) {
        // Create a storage reference from our app
        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference storageRef = storage.getReference();

// Create a reference to the file to delete
        StorageReference desertRef = storageRef.child("ImagePK/"+id);

// Delete the file
        desertRef.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                // File deleted successfully
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                // Uh-oh, an error occurred!
            }
        });
        callFragment();
    }
    //loadLoaiThuCung
    private void loadTl() {
        DatabaseReference reference;
        reference = FirebaseDatabase.getInstance().getReference("LoaiThuCung");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                loaiThuCungs.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    loaiThuCung thuCung = dataSnapshot.getValue(loaiThuCung.class);
                    loaiThuCungs.add(thuCung);
                    System.out.println(loaiThuCungs.size());
                }
                List<String> dataset = new ArrayList<>();
                for (int i = 0; i < loaiThuCungs.size(); i++) {
                    System.out.println(loaiThuCungs.get(i).getLoaiThuCung());
                    dataset.add(loaiThuCungs.get(i).getLoaiThuCung());
                }
                if(loaiThuCungs.size()==1){
                    spinner.setText(loaiThuCungs.get(0).getLoaiThuCung());
                }
                else{
                    spinner.attachDataSource(dataset);
                }
                spinner.setOnSpinnerItemSelectedListener(new OnSpinnerItemSelectedListener() {
                    @Override
                    public void onItemSelected(NiceSpinner parent, View view, int position, long id) {
                        // This example uses String, but your type can be any
                        item = position;
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    //validate

    private boolean validatename() {
        String _name = name.getEditText().getText().toString().trim();
        if (_name.isEmpty()) {
            name.setError("Không được bỏ trống!");
            name.requestFocus();
            return false;
        } else if (_name.length() > 30) {
            name.setError(("Tên quá dài!"));
            return false;
        } else {
            name.setError(null);
            name.setErrorEnabled(false);
            return true;
        }
    }


    private boolean validateQuantity() {
        String _quantity = quantity.getEditText().getText().toString().trim();
        if (_quantity.isEmpty()) {
            quantity.setError("Không được bỏ trống!");
            quantity.requestFocus();
            return false;
        }else if(_quantity.length() > 8) {
            price.setError("Số quá lớn!");
            return false;
        }else
            quantity.setError(null);
        quantity.setErrorEnabled(false);
        return true;
    }
    private boolean validatePrice() {
        String _price = price.getEditText().getText().toString().trim();
        if (_price.isEmpty()) {
            price.setError("Không được bỏ trống!");
            price.requestFocus();
            return false;
        }else if(_price.length() > 18){
            price.setError("Số quá lớn!");
            return false;
        }
        else
            price.setError(null);
        price.setErrorEnabled(false);
        return true;
    }
}