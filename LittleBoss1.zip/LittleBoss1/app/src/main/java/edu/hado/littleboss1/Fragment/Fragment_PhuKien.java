package edu.hado.littleboss1.Fragment;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.melnykov.fab.FloatingActionButton;

import java.util.ArrayList;

import cn.pedant.SweetAlert.SweetAlertDialog;
import edu.hado.littleboss1.Activity.MainActivity;
import edu.hado.littleboss1.Adapter.adapterFirebasePK;
import edu.hado.littleboss1.Adapter.adapterLoadPK;
import edu.hado.littleboss1.Model.loaiThuCung;
import edu.hado.littleboss1.Model.phuKien;
import edu.hado.littleboss1.R;

public class Fragment_PhuKien extends Fragment {
    private FloatingActionButton fab;
    private RecyclerView recyclerView;
    private SearchView searchText;
    private Class fragmentClass;
    private ArrayList<phuKien> phukiens = new ArrayList<>();
    ArrayList<loaiThuCung> list;
    private phuKien mphukien;
    private adapterLoadPK loadPk;
    private MainActivity activity;
    public static Fragment fragment;
    SweetAlertDialog pDialog;

    public Fragment_PhuKien() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_phu_kien, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        fab = (FloatingActionButton) view.findViewById(R.id.fab);
        recyclerView = view.findViewById(R.id.rc_thucung);
        searchText = view.findViewById(R.id.searchEdt);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager llm = new LinearLayoutManager(requireActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(llm);
        fab.attachToRecyclerView(recyclerView);
        fab.setType(FloatingActionButton.TYPE_MINI);
        fab.setOnClickListener(this::themphukien);
        activity = (MainActivity) getActivity();
        list = new ArrayList<>();
        showProgress();
        loadPK();
        listtv();
        searchText.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                progresssearch(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                progresssearch(newText);
                return false;
            }
        });
    }


    //progress
    private void showProgress() {
        pDialog = new SweetAlertDialog(requireContext(), SweetAlertDialog.PROGRESS_TYPE);
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#A5DC86"));
        pDialog.setTitleText("Loading");
        pDialog.setCancelable(false);
        pDialog.show();
    }

    //thêm phụ kiện
    private void themphukien(View view) {
        if(list.size() == 0){
            new SweetAlertDialog(requireContext() , SweetAlertDialog.WARNING_TYPE)
                    .setTitleText("Chưa có dữ liệu loại thú cưng vui lòng thêm loại thú cưng !")
                    .show();
            return;
        }
        fragmentClass = Fragment_ThemPhuKien.class;
        try {
            fragment = (Fragment) fragmentClass.newInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (fragment != null) {
            FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();
            fragmentManager.beginTransaction().setCustomAnimations(android.R.animator.fade_in, android.R.animator.fade_out).replace(R.id.frameLayout, fragment).commit();
        }
    }
    //loai thu cưng
    private void listtv(){
        FirebaseDatabase.getInstance().getReference("LoaiThuCung")
                .addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                list.clear();
                for (DataSnapshot dataSnapshot:snapshot.getChildren() ){
                    loaiThuCung thuCung = dataSnapshot.getValue(loaiThuCung.class);
                    list.add(thuCung);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    //loadPK
    private void loadPK() {
        DatabaseReference reference;
        reference = FirebaseDatabase.getInstance().getReference("PhuKien");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                phukiens.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    phuKien thuCung = dataSnapshot.getValue(phuKien.class);
                    phukiens.add(thuCung);
                    System.out.println(phukiens.size());
                }
                GridLayoutManager gridLayoutManager = new GridLayoutManager(activity, 2,RecyclerView.VERTICAL,false);
                recyclerView.setLayoutManager(gridLayoutManager);
                loadPk = new adapterLoadPK(Fragment_PhuKien.this, phukiens,activity);
                recyclerView.setAdapter(loadPk);
                pDialog.dismissWithAnimation();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    private void progresssearch(String s) {
        adapterFirebasePK adapterFirebase;
        FirebaseRecyclerOptions<phuKien> options =
                new FirebaseRecyclerOptions.Builder<phuKien>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("PhuKien").orderByChild("tenPhuKien").startAt(s).endAt(s+"\uf8ff"), phuKien.class)
                        .build();
        System.out.println(options);
        adapterFirebase = new adapterFirebasePK(options,Fragment_PhuKien.this,phukiens);
        adapterFirebase.startListening();
        recyclerView.setAdapter(adapterFirebase);
    }
}