package edu.hado.littleboss1.Fragment;


import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;

import java.io.IOException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;

public class veify {
    private static final String KEY_FACTORY_ALGORITHM = "RSA";
    private static final String SIGNATURE_ALGORITHM = "SHAlwithRSA";
    private static final String TAG = "TAGAPI";
    public static boolean verifyPurchase(String base64PublicKey, String signedData, String signature) throws IOException {
        if (TextUtils.isEmpty(signedData) || TextUtils.isEmpty(base64PublicKey) || TextUtils.isEmpty(signature)) {
            Log.e("TAGAPI", "Purchase verification failed: missing data.");
            return false;
        }
        PublicKey key = generatePublicKey(base64PublicKey);
        return verify(key, signedData, signature);
    }

    private static PublicKey generatePublicKey(String base64PublicKey) {
        try {
            byte[] keyBytes = Base64.decode(base64PublicKey, 0);
            KeyFactory keyFactory = KeyFactory.getInstance(KEY_FACTORY_ALGORITHM);
            return keyFactory.generatePublic(new X509EncodedKeySpec(keyBytes));
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        } catch (InvalidKeySpecException e) {
            Log.e("TAGAPI", "Invalid key specification." + e);
            throw new IllegalArgumentException(e);
        }
    }

    private static boolean verify(PublicKey publicKey, String signedData, String signature) {
        byte[] signatureBytes;
        try {
            signatureBytes = Base64.decode(signature, 0);
        } catch (IllegalArgumentException e) {
            Log.e(TAG, "Base64 decoding failed." + e);
            return false;
        }
        try {
            java.security.Signature sig = java.security.Signature.getInstance(SIGNATURE_ALGORITHM);
            sig.initVerify(publicKey);
            sig.update(signedData.getBytes());
            if (!sig.verify(signatureBytes)) {
                Log.e(TAG, "Signature verification failed.");
                return false;
            }
            return true;
        } catch (NoSuchAlgorithmException e) {
            Log.e(TAG, "NoSuchAlgorithmException." + e);
        } catch (java.security.InvalidKeyException e) {
            Log.e(TAG, "Invalid key specification." + e);
        } catch (java.security.SignatureException e) {
            Log.e(TAG, "Signature exception." + e);
        }
        return false;
    }
}
