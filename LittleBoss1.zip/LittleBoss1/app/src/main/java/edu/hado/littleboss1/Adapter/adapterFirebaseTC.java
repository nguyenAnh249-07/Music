package edu.hado.littleboss1.Adapter;

import static edu.hado.littleboss1.Fragment.Fragment_TTTC.id3;

import android.annotation.SuppressLint;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

import java.util.ArrayList;
import java.util.List;

import edu.hado.littleboss1.Fragment.Fragment_TTTC;
import edu.hado.littleboss1.Fragment.Fragment_ThuCung;
import edu.hado.littleboss1.Model.phuKien;
import edu.hado.littleboss1.Model.thuCung;
import edu.hado.littleboss1.R;

public class adapterFirebaseTC extends FirebaseRecyclerAdapter<thuCung,adapterFirebaseTC.myviewholder>
{
    Fragment_ThuCung context;
    public ArrayList<thuCung> ThuCungs;
    public static thuCung nthuCung = new thuCung();

    public adapterFirebaseTC(@NonNull FirebaseRecyclerOptions<thuCung> options ,Fragment_ThuCung thuCung,ArrayList<thuCung> mThuCungs) {
        super(options);
        this.context = thuCung;
        this.ThuCungs = mThuCungs;
    }

    @Override
    protected void onBindViewHolder(@NonNull myviewholder holder, @SuppressLint("RecyclerView")final int position, @NonNull thuCung model)
    {
        nthuCung = model;
        holder.name.setText(model.getTenThuCung());
        holder.price.setText(Html.fromHtml(model.getGia()+"<sup><small>₫</small></sup>"));
        holder.sl.setText(""+model.getSoLuong());
        holder.progressBar.setVisibility(View.GONE);
        Glide.with(context)
                .load(model.getHinh())
                .into(holder.imageView);
        holder.progressBar.setVisibility(View.VISIBLE);

        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment fragment = new Fragment();
                Class fragmentClass = Fragment_TTTC.class;
                nthuCung = model;
                id3 = 2;
                try {
                    fragment = (Fragment) fragmentClass.newInstance();

                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (fragment != null) {
                    FragmentManager fragmentManager = context.getParentFragmentManager();
                    fragmentManager.beginTransaction().setCustomAnimations(android.R.animator.fade_in, android.R.animator.fade_out)
                            .replace(R.id.frameLayout, fragment).commit();
                }
            }
        });
    }
    public void updatedata(List<phuKien> data) {
        data.clear();
        data.addAll(data);
        notifyDataSetChanged();
    }
    @NonNull
    @Override
    public myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_thu_cung,parent,false);
        return new myviewholder(view);
    }


    class myviewholder extends RecyclerView.ViewHolder
    {
        TextView name, price, sl;
        ImageView imageView;
        ProgressBar progressBar;
        LinearLayout linearLayout;
        public myviewholder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.itemTC_name);
            price = itemView.findViewById(R.id.itemTC_price);
            sl = (TextView) itemView.findViewById(R.id.itemTC_quantity);
            imageView = (ImageView) itemView.findViewById(R.id.itemTC_image);
            progressBar = itemView.findViewById(R.id.progress);
            linearLayout = itemView.findViewById(R.id.layout_TC);
        }
    }
}
