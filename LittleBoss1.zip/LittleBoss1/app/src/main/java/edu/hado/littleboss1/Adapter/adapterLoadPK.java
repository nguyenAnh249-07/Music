package edu.hado.littleboss1.Adapter;

import static edu.hado.littleboss1.Fragment.Fragment_TTPK.flag;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

import edu.hado.littleboss1.Fragment.Fragment_PhuKien;
import edu.hado.littleboss1.Fragment.Fragment_TTPK;
import edu.hado.littleboss1.Model.phuKien;
import edu.hado.littleboss1.R;

public class adapterLoadPK extends RecyclerView.Adapter<adapterLoadPK.ViewHolder> {
    Fragment_PhuKien context;
    public ArrayList<phuKien> phuKiens;
    phuKien mphukien;
    Context context1;

    public static phuKien n2phukien = new phuKien();

    public adapterLoadPK(Fragment_PhuKien context, ArrayList<phuKien> thuCungs,Context context1) {
        this.context = context;
        this.context1 = context1;
        phuKiens = thuCungs;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context.requireActivity()).inflate(R.layout.item_thu_cung, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        mphukien = phuKiens.get(position);

        holder.name.setText(mphukien.getTenPhuKien());
        holder.price.setText(Html.fromHtml(mphukien.getGia()+"<sup><small>₫</small></sup>"));
        holder.sl.setText(""+ mphukien.getSoluong());
        holder.progressBar.setVisibility(View.VISIBLE);
        Glide.with(context)
                .load(mphukien.getHinh())
                .into(holder.imageView);
        holder.progressBar.setVisibility(View.GONE);
//        holder.layoutDelete.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String aa = phuKiens.get(position).getMaPhuKien();
//                new SweetAlertDialog(context.requireContext(), SweetAlertDialog.WARNING_TYPE)
//                        .setTitleText("Bạn chắc chứ?")
//                        .setContentText("Sẽ không thể khôi phục dữ liệu này!")
//                        .setConfirmButton("Có,tôi muốn xóa nó!", sweetAlertDialog -> {
//                            FirebaseDatabase.getInstance().getReference().child("PhuKien").child(aa).removeValue()
//                                    .addOnCompleteListener(command -> FirebaseStorage.getInstance().getReference().child("ImagePK/"+aa).delete())
////                                    .addOnCompleteListener(command -> updatedata(phuKiens))
//                                    .addOnCompleteListener(command -> sweetAlertDialog.dismiss());
//                        })
//                        .setCancelButton("Không,tôi nghĩ lại rồi:>", SweetAlertDialog::dismiss)
//                        .show();
//            }
//        });
        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment fragment = new Fragment();
                Class fragmentClass = Fragment_TTPK.class;
                n2phukien = phuKiens.get(position);
                flag(2);
                try {
                    fragment = (Fragment) fragmentClass.newInstance();

                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (fragment != null) {
                    FragmentManager fragmentManager = context.getParentFragmentManager();
                    fragmentManager.beginTransaction().setCustomAnimations(android.R.animator.fade_in, android.R.animator.fade_out)
                            .replace(R.id.frameLayout, fragment).commit();
                }
            }
        });
    }

    public void updatedata(List<phuKien> data) {
        data.clear();
        data.addAll(data);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return phuKiens.size();
    }


    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, price, sl;
        ImageView imageView;
        ProgressBar progressBar;
        LinearLayout linearLayout;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.itemTC_name);
            price = itemView.findViewById(R.id.itemTC_price);
            sl = (TextView) itemView.findViewById(R.id.itemTC_quantity);
            imageView = (ImageView) itemView.findViewById(R.id.itemTC_image);
            progressBar = itemView.findViewById(R.id.progress);
            linearLayout = itemView.findViewById(R.id.layout_TC);
        }
    }
}
