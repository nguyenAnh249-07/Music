package edu.hado.littleboss1.Model;

public class hoaDonChiTiet {
   private String maHDCT,maHD,maPK,maTC,tongTien;
   private int sLTC,sLPK;

    public hoaDonChiTiet(String maHDCT, String maHD, String maPK, String maTC, String tongTien, int sLTC, int sLPK) {
        this.maHDCT = maHDCT;
        this.maHD = maHD;
        this.maPK = maPK;
        this.maTC = maTC;
        this.tongTien = tongTien;
        this.sLTC = sLTC;
        this.sLPK = sLPK;
    }

    public hoaDonChiTiet() {
    }

    public String getMaHDCT() {
        return maHDCT;
    }

    public void setMaHDCT(String maHDCT) {
        this.maHDCT = maHDCT;
    }

    public String getMaHD() {
        return maHD;
    }

    public void setMaHD(String maHD) {
        this.maHD = maHD;
    }

    public String getMaPK() {
        return maPK;
    }

    public void setMaPK(String maPK) {
        this.maPK = maPK;
    }

    public String getMaTC() {
        return maTC;
    }

    public void setMaTC(String maTC) {
        this.maTC = maTC;
    }

    public String getTongTien() {
        return tongTien;
    }

    public void setTongTien(String tongTien) {
        this.tongTien = tongTien;
    }

    public int getsLTC() {
        return sLTC;
    }

    public void setsLTC(int sLTC) {
        this.sLTC = sLTC;
    }

    public int getsLPK() {
        return sLPK;
    }

    public void setsLPK(int sLPK) {
        this.sLPK = sLPK;
    }
}
