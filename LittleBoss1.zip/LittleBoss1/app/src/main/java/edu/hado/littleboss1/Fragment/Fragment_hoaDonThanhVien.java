package edu.hado.littleboss1.Fragment;

import static edu.hado.littleboss1.Fragment.Fragment_ThanhVien.maTV;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import cn.pedant.SweetAlert.SweetAlertDialog;
import edu.hado.littleboss1.Activity.MainActivity;
import edu.hado.littleboss1.Adapter.adapteHoaDon;
import edu.hado.littleboss1.Model.hoaDon;
import edu.hado.littleboss1.R;

public class Fragment_hoaDonThanhVien extends Fragment {

    private RecyclerView recyclerView;
    private ArrayList<hoaDon> hoaDons = new ArrayList<>();
    private adapteHoaDon loadhd;
    private MainActivity activity;
    SweetAlertDialog pDialog;

    public Fragment_hoaDonThanhVien() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //Inflate the layout for this fragment

        return inflater.inflate(R.layout.fragment_hoa_don_thanh_vien, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = view.findViewById(R.id.rc_loaithu);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        activity = (MainActivity) getActivity();
        showProgress();
        loadHD();
    }


    //progress
    private void showProgress() {
        pDialog = new SweetAlertDialog(requireContext(), SweetAlertDialog.PROGRESS_TYPE);
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#A5DC86"));
        pDialog.setTitleText("Loading");
        pDialog.setCancelable(false);
        pDialog.show();
    }

    private void loadHD(){
        Query reference;
        reference = FirebaseDatabase.getInstance().getReference("HoaDon").orderByChild("maTV").equalTo(maTV);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot:snapshot.getChildren() ){
                    hoaDon hoadon = dataSnapshot.getValue(hoaDon.class);
                    hoaDons.add(hoadon);
                }
                loadhd = new adapteHoaDon(Fragment_hoaDonThanhVien.this,hoaDons,activity);
                recyclerView.setAdapter(loadhd);
                pDialog.dismissWithAnimation();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}