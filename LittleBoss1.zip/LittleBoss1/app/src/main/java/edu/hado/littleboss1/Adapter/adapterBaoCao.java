package edu.hado.littleboss1.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import edu.hado.littleboss1.Model.baoCao;
import edu.hado.littleboss1.R;

public class adapterBaoCao extends RecyclerView.Adapter<adapterBaoCao.ViewHolder>{
    Context context;
    List<baoCao> baoCaos;

    public adapterBaoCao(Context context, List<baoCao> baoCaos) {
        this.context = context;
        this.baoCaos = baoCaos;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_baocao, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        baoCao baoCao = baoCaos.get(position);
        holder.date.setText(baoCao.getDate());
        holder.tongTien.setText(baoCao.getTongTien() + " đ");
    }

    @Override
    public int getItemCount() {
        return baoCaos.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView date, tongTien;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            date = itemView.findViewById(R.id.tv_ngay);
            tongTien = itemView.findViewById(R.id.tv_tongtien);
        }
    }
}
