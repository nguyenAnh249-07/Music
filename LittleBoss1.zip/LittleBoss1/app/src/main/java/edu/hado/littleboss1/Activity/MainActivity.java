package edu.hado.littleboss1.Activity;

import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.shrikanthravi.customnavigationdrawer2.data.MenuItem;
import com.shrikanthravi.customnavigationdrawer2.widget.SNavigationDrawer;

import java.util.ArrayList;
import java.util.List;

import edu.hado.littleboss1.Fragment.Fragment_BaoCao;
import edu.hado.littleboss1.Fragment.Fragment_LoaiThu;
import edu.hado.littleboss1.Fragment.Fragment_PhuKien;
import edu.hado.littleboss1.Fragment.Fragment_ThanhVien;
import edu.hado.littleboss1.Fragment.Fragment_ThuCung;
import edu.hado.littleboss1.Fragment.thongtinappFragment;
import edu.hado.littleboss1.R;

public class MainActivity extends AppCompatActivity {

    //Global Declaration
    SNavigationDrawer sNavigationDrawer;
    Class fragmentClass;
    private static Fragment fragment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        sNavigationDrawer = findViewById(R.id.navigationDrawer);
        List<MenuItem> menuItems = new ArrayList<>();
        menuItems.add(new MenuItem("Quản lý thú cưng",R.drawable.thiennhien1));
        menuItems.add(new MenuItem("Quản lý phụ kiện",R.drawable.thiennhien2));
        menuItems.add(new MenuItem("Quản lý loại thú cưng",R.drawable.thiennhien3));
//        menuItems.add(new MenuItem("Quản lý thành viên",R.drawable.thiennhien4));
//        menuItems.add(new MenuItem("Báo Cáo",R.drawable.thiennhien1));
        menuItems.add(new MenuItem("Giới thiệu ứng dụng",R.drawable.thiennhien3));
        //then add them to navigation drawer

        sNavigationDrawer.setMenuItemList(menuItems);
        fragmentClass =  Fragment_ThuCung.class;
        try {
            fragment = (Fragment) fragmentClass.newInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (fragment != null) {
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.beginTransaction().setCustomAnimations(android.R.animator.fade_in, android.R.animator.fade_out).replace(R.id.frameLayout, fragment).commit();
        }
        sNavigationDrawer.setOnMenuItemClickListener(new SNavigationDrawer.OnMenuItemClickListener() {
            @Override
            public void onMenuItemClicked(int position) {
                System.out.println("Position "+position);

                switch (position){
                    case 0:{
                        fragmentClass = Fragment_ThuCung.class;
                        break;
                    }
                    case 1:{
                        fragmentClass = Fragment_PhuKien.class;
                        break;
                    }
                    case 2:{
                        fragmentClass = Fragment_LoaiThu.class;
                        break;
                    }
                    case 3:{
                        fragmentClass = thongtinappFragment.class;
                        break;
                    }
//                    case 4:{
//                        fragmentClass = Fragment_BaoCao.class;
//                        break;
//                    }

                }
            }
        });


        //Listener for drawer events such as opening and closing.
        sNavigationDrawer.setDrawerListener(new SNavigationDrawer.DrawerListener() {

            @Override
            public void onDrawerOpened() {

            }

            @Override
            public void onDrawerOpening(){

            }

            @Override
            public void onDrawerClosing(){
                System.out.println("Drawer closed");

                try {
                    fragment = (Fragment) fragmentClass.newInstance();
                } catch (Exception e) {
                    e.printStackTrace();
                }

                if (fragment != null) {
                    FragmentManager fragmentManager = getSupportFragmentManager();
                    fragmentManager.beginTransaction().setCustomAnimations(android.R.animator.fade_in, android.R.animator.fade_out).replace(R.id.frameLayout, fragment).commit();

                }
            }

            @Override
            public void onDrawerClosed() {

            }

            @Override
            public void onDrawerStateChanged(int newState) {
                System.out.println("State "+newState);
            }
        });
    }

    //thoát chương trình
    boolean doubleBackToExitPressedOnce = false;

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Ấn quay lại lần nữa để thoát chương trình", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }
}