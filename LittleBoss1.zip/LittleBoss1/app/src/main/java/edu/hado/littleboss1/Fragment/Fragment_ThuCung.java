package edu.hado.littleboss1.Fragment;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.melnykov.fab.FloatingActionButton;

import java.util.ArrayList;

import cn.pedant.SweetAlert.SweetAlertDialog;
import edu.hado.littleboss1.Activity.MainActivity;
import edu.hado.littleboss1.Adapter.adapterFirebaseTC;
import edu.hado.littleboss1.Adapter.adapterLoadTC;
import edu.hado.littleboss1.Model.loaiThuCung;
import edu.hado.littleboss1.Model.thuCung;
import edu.hado.littleboss1.R;

public class Fragment_ThuCung extends Fragment {
    private FloatingActionButton fab;
    private RecyclerView recyclerView;
    private SearchView searchText;
    private Class fragmentClass;
    private ArrayList<thuCung> thuCungs;
    ArrayList<loaiThuCung> list;
    private thuCung mthuCung;
    private adapterLoadTC loadtc;
    public static Fragment fragment;
    private MainActivity activity;
    SweetAlertDialog pDialog;
    public Fragment_ThuCung() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_thu_cung, container, false);

        return view ;
}

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        fab = (FloatingActionButton) view.findViewById(R.id.fab);
        recyclerView = view.findViewById(R.id.rc_thucung);
        searchText = view.findViewById(R.id.searchEdt);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager llm = new LinearLayoutManager(requireActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(llm);
        fab.attachToRecyclerView(recyclerView);
        fab.setType(FloatingActionButton.TYPE_MINI);
        activity = (MainActivity) getActivity();
        fab.setOnClickListener(this::themthucung);
        thuCungs = new ArrayList<>();
        list = new ArrayList<>();
        showProgress();
        listtv();
        searchText.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                progresssearch(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                progresssearch(newText);
                return false;
            }
        });
    }

    private void progresssearch(String s) {
        adapterFirebaseTC adapterFirebase;
        FirebaseRecyclerOptions<thuCung> options =
                new FirebaseRecyclerOptions.Builder<thuCung>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("ThuCung").orderByChild("tenThuCung").startAt(s).endAt(s+"\uf8ff"), thuCung.class)
                        .build();
        System.out.println(options);
        adapterFirebase = new adapterFirebaseTC(options,Fragment_ThuCung.this,thuCungs);
        adapterFirebase.startListening();
        recyclerView.setAdapter(adapterFirebase);
    }

    //progress
    private void showProgress(){
        pDialog = new SweetAlertDialog(requireContext(), SweetAlertDialog.PROGRESS_TYPE);
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#A5DC86"));
        pDialog.setTitleText("Loading");
        pDialog.setCancelable(false);
        pDialog.show();
    }
    //thêm thú cưng
    private void themthucung(View view){
        if(list.size() == 0){
            new SweetAlertDialog(requireContext() , SweetAlertDialog.WARNING_TYPE)
            .setTitleText("Chưa có dữ liệu loại thú cưng vui lòng thêm loại thú cưng !")
            .show();
            return;
        }
        fragmentClass =  Fragment_ThemThuCung.class;
        try {
            fragment = (Fragment) fragmentClass.newInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (fragment != null) {
            FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();
            fragmentManager.beginTransaction().setCustomAnimations(android.R.animator.fade_in, android.R.animator.fade_out).replace(R.id.frameLayout, fragment).commit();
        }
    }
    //loai thu cưng
    private void listtv(){
        FirebaseDatabase.getInstance().getReference("LoaiThuCung")
                .addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()) {
                    list.clear();
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                        loaiThuCung thuCung = dataSnapshot.getValue(loaiThuCung.class);
                        list.add(thuCung);
                        System.out.println(thuCungs.size());
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    // load thú cưng
    private void loadTC(){
        DatabaseReference reference;
        reference = FirebaseDatabase.getInstance().getReference("ThuCung");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                pDialog.dismissWithAnimation();
                if(!snapshot.exists()){
                    return;
                }
                thuCungs.clear();
                for (DataSnapshot dataSnapshot:snapshot.getChildren() ){
                    thuCung thuCung = dataSnapshot.getValue(thuCung.class);
                    thuCungs.add(thuCung);
                    System.out.println(thuCungs.size());
                }
                GridLayoutManager gridLayoutManager = new GridLayoutManager(activity, 2,RecyclerView.VERTICAL,false);
                recyclerView.setLayoutManager(gridLayoutManager);
                loadtc = new adapterLoadTC(activity,thuCungs,Fragment_ThuCung.this);
                recyclerView.setAdapter(loadtc);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        loadTC();
    }
}