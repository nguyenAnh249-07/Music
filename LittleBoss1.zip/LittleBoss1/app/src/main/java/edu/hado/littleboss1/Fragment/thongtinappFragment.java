package edu.hado.littleboss1.Fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ConsumeParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.ProductDetailsResponseListener;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.google.firebase.crashlytics.buildtools.reloc.com.google.common.collect.ImmutableList;

import java.io.IOException;
import java.util.List;

import edu.hado.littleboss1.databinding.FragmentThongtinappBinding;


/**
 * A simple {@link Fragment} subclass.
 * Use the {@link thongtinappFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class thongtinappFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    TextView txtThongTin;
    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    FragmentThongtinappBinding binding;
    private BillingClient billingClient;

    public thongtinappFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment thongtinappFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static thongtinappFragment newInstance(String param1, String param2) {
        thongtinappFragment fragment = new thongtinappFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        String thongtin = "Ứng dụng được phát hành bởi DevNguyenAnh \n" +
                " Ứng dụng vẫn còn những thiếu sót cần đưược phát triển sau. \n";
        binding.textviewthongtin.setText(thongtin);

        billingClient = BillingClient.newBuilder(requireContext())
                .enablePendingPurchases()
                .setListener(purchasesUpdatedListener)
                .build();



        binding.Cardweek049.setOnClickListener(v -> {
            initiatePurchase("week_0.49");//1$
        });
        binding.Cardweek099.setOnClickListener(v -> {
            initiatePurchase("week_0.99");//5$
        });
        binding.Cardmonth999.setOnClickListener(v -> {
            initiatePurchase("month_9.99");//20$
        });
        binding.Card6month1999.setOnClickListener(v -> {
            initiatePurchase("6month_19.99");//50$
        });
        binding.Cardyear3999.setOnClickListener(v -> {
            initiatePurchase("year_39.99");//100$
        });

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentThongtinappBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    private void initiatePurchase(String productId) {
        billingClient.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(BillingResult billingResult) {
                if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    Log.d("TAGAPI", "onBillingSetupFinished: ");

                    QueryProductDetailsParams queryProductDetailsParams = QueryProductDetailsParams.newBuilder()
                            .setProductList(
                                    ImmutableList.of(
                                            QueryProductDetailsParams.Product.newBuilder()
                                                    .setProductId(productId)
                                                    .setProductType(BillingClient.ProductType.INAPP)
                                                    .build()
                                    )
                            )
                            .build();
                    Log.d("TAGAPI", "onBillingSetupFinished2: " + queryProductDetailsParams.zza());
                    billingClient.queryProductDetailsAsync(queryProductDetailsParams, new ProductDetailsResponseListener() {
                        @Override
                        public void onProductDetailsResponse(@NonNull BillingResult billingResult, @NonNull List<ProductDetails> productDetailsList) {
                            if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK && !productDetailsList.isEmpty()) {
                                ProductDetails productDetails = productDetailsList.get(0);
                                ImmutableList<BillingFlowParams.ProductDetailsParams> productDetailsParamsList =
                                        ImmutableList.of(
                                                BillingFlowParams.ProductDetailsParams.newBuilder()
                                                        .setProductDetails(productDetails)
                                                        .build()
                                        );

                                BillingFlowParams billingFlowParams = BillingFlowParams.newBuilder()
                                        .setProductDetailsParamsList(productDetailsParamsList)
                                        .build();
                                // Launch the billing flow
                                BillingResult billingResult1 = billingClient.launchBillingFlow(requireActivity(), billingFlowParams);
                                //hiện dialog mua hàng
                                Log.d("TAGAPI", "onProductDetailsResponse: " + billingResult1.getResponseCode());
                            }else{
                                Log.d("TAGAPI", "onProductDetailsResponse: " + productDetailsList.size());
                            }
                        }
                    });
                }
            }

            @Override
            public void onBillingServiceDisconnected() {
                // Handle the case of disconnection from Google Play Billing
                Log.d("TAGAPI", "onBillingServiceDisconnected: ");
            }
        });
    }

// Set OnClickListener for Cardweek099



    // Listener để theo dõi kết quả của giao dịch
    PurchasesUpdatedListener purchasesUpdatedListener = new PurchasesUpdatedListener() {
        @Override
        public void onPurchasesUpdated(BillingResult billingResult, @Nullable List<Purchase> purchases) {
            if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
                // Xử lý kết quả của giao dịch ở đây
                Log.d("TAGAPI", "onPurchasesUpdated: ");
                for (Purchase purchase : purchases) {
                    handlePurchase(purchase);
                }
            } else {
                // Xử lý trường hợp không thành công
                Log.d("TAGAPI", "onPurchasesUpdated: " + billingResult.getResponseCode());
            }
        }
    };


    private void handlePurchase(Purchase purchase) {
        ConsumeParams consumeParams = ConsumeParams.newBuilder()
                .setPurchaseToken(purchase.getPurchaseToken())
                .build();
        billingClient.consumeAsync(consumeParams, (billingResult, purchaseToken) -> {
            if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                // Xử lý trường hợp mua hàng thành công
            } else {
                // Xử lý trường hợp mua hàng không thành công
            }
        });

        // Xử lý trường hợp mua hàng thành công

        if (purchase.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
            Log.d("TAGAPI", "handlePurchase: " + purchase.getOriginalJson());
            // Mua hàng thành công
            if (!verifyValidSignature(purchase.getOriginalJson(), purchase.getSignature())) {
                Toast.makeText(requireContext(),
                        "Purchase failed: Invalid signature",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            if (purchase.isAcknowledged()) {
                AcknowledgePurchaseParams acknowledgePurchaseParams = AcknowledgePurchaseParams.newBuilder()
                        .setPurchaseToken(purchase.getPurchaseToken())
                        .build();
                billingClient.acknowledgePurchase(acknowledgePurchaseParams, billingResult -> {
                    if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                        // Xử lý trường hợp mua hàng thành công
                    } else {
                        // Xử lý trường hợp mua hàng không thành công
                    }
                });
            }
        } else if (purchase.getPurchaseState() == Purchase.PurchaseState.PENDING) {
            // Mua hàng đang chờ xử lý
        } else if (purchase.getPurchaseState() == Purchase.PurchaseState.UNSPECIFIED_STATE) {
            // Trạng thái mua hàng không xác định
        }

    }


    private boolean verifyValidSignature(String originalJson, String signature) {
        try {
            String base64Key = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsSzU37CADTqY5IWJls05pL8FZzoe4B8Xh183SspPjVGB51v9ZvLSmpwGeKwkK7OOT55aqsZnURRjyI17+DucAl1ZpfARAQ7uxJ9Ug7vdI87tdlZz5XiosIF3TCyL6DtQ0EYIPccWL3uqHS5eAcT7S1L6es0ZRguOv5tO1uyO8ZvXUpuxHqkbSg5GYgLE94SpQrIJ5uUr0eBRRI/V9RL2cbk0IGeWipOMxtITlDddLRqh/jN54n2Sr+bGbliYTCZYAo1hpowVmJW9IAQeKJuOu9F5IUfxoYvcqEwEZJcKvW46IQuz8/jnxygCSFBeNGkL7hmYRQa7jgQ3L4sNUZydkwIDAQAB";
            return veify.verifyPurchase(base64Key, originalJson, signature);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return true;
    }
}