package edu.hado.littleboss1.Adapter;


import static edu.hado.littleboss1.Fragment.Fragment_hoaDonChiTiet.maHD;
import static edu.hado.littleboss1.Model.fromattime.fromatTime;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import edu.hado.littleboss1.Fragment.Fragment_hoaDonChiTiet;
import edu.hado.littleboss1.Fragment.Fragment_hoaDonThanhVien;
import edu.hado.littleboss1.Model.hoaDon;
import edu.hado.littleboss1.Model.loaiThuCung;
import edu.hado.littleboss1.R;

public class adapteHoaDon extends RecyclerView.Adapter<adapteHoaDon.ViewHolder> {
    Fragment_hoaDonThanhVien fragment_hoaDonThanhVien;
    Context context;
    ArrayList<hoaDon> hoaDons;
    public adapteHoaDon(Fragment_hoaDonThanhVien fragment_hoaDonThanhVien, ArrayList<hoaDon> hoaDons, Context context) {
        this.fragment_hoaDonThanhVien = fragment_hoaDonThanhVien;
        this.hoaDons = hoaDons;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.item_hoadon, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        hoaDon vien = hoaDons.get(position);
        holder.name.setText("Tên Nhân Viên: "+vien.getNhanVien());
        holder.date.setText("Ngày Tạo : "+fromatTime(Long.parseLong(vien.getNgayTao())));
        holder.layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int i = position;
                Fragment fragment = new Fragment();
                Class fragmentClass = Fragment_hoaDonChiTiet.class;
                maHD = hoaDons.get(i).getMaHD();
                try {
                    fragment = (Fragment) fragmentClass.newInstance();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (fragment != null) {
                    FragmentManager fragmentManager =fragment_hoaDonThanhVien.getParentFragmentManager() ;
                    fragmentManager.beginTransaction().setCustomAnimations(android.R.animator.fade_in, android.R.animator.fade_out)
                            .replace(R.id.frameLayout, fragment).commit();
                }
            }
        });
    }

    public void updatedata(List<loaiThuCung> data) {
        data.clear();
        data.addAll(data);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return hoaDons.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name,date;
        RelativeLayout layout;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.nameNV);
            date = itemView.findViewById(R.id.datecreate);
            layout = itemView.findViewById(R.id.clicktv);
        }
    }
}
