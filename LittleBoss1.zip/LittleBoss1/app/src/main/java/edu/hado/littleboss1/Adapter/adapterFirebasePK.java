package edu.hado.littleboss1.Adapter;


import static edu.hado.littleboss1.Fragment.Fragment_TTPK.flag;

import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

import java.util.ArrayList;
import java.util.List;

import edu.hado.littleboss1.Fragment.Fragment_PhuKien;
import edu.hado.littleboss1.Fragment.Fragment_TTPK;
import edu.hado.littleboss1.Model.phuKien;
import edu.hado.littleboss1.R;

public class adapterFirebasePK extends FirebaseRecyclerAdapter<phuKien,adapterFirebasePK.myviewholder>
{
    Fragment_PhuKien context;
    public ArrayList<phuKien> ThuCungs;
    public static phuKien nphukien = new phuKien();

    public adapterFirebasePK(@NonNull FirebaseRecyclerOptions<phuKien> options , Fragment_PhuKien thuCung, ArrayList<phuKien> mThuCungs) {
        super(options);
        this.context = thuCung;
        this.ThuCungs = mThuCungs;
    }



    @NonNull
    @Override
    public myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_thu_cung,parent,false);
        return new myviewholder(view);
    }

    @Override
    protected void onBindViewHolder(@NonNull myviewholder holder, int position, @NonNull phuKien model) {
        nphukien = model;
        holder.name.setText(model.getTenPhuKien());
        holder.price.setText(Html.fromHtml(model.getGia()+"<sup><small>₫</small></sup>"));
        holder.sl.setText(""+model.getSoluong());
        holder.progressBar.setVisibility(View.GONE);
        Glide.with(context)
                .load(model.getHinh())
                .into(holder.imageView);
        holder.progressBar.setVisibility(View.VISIBLE);
//        holder.layoutDelete.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                new SweetAlertDialog(context.requireContext(), SweetAlertDialog.WARNING_TYPE)
//                        .setTitleText("Bạn chắc chứ?")
//                        .setContentText("Sẽ không thể khôi phục dữ liệu này!")
//                        .setConfirmButton("Có,tôi muốn xóa nó!", sweetAlertDialog -> {
//                            FirebaseDatabase.getInstance().getReference().child("PhuKien").child(model.getMaPhuKien()).removeValue()
//                                    .addOnCompleteListener(command -> FirebaseStorage.getInstance().getReference().child("ImagePK/"+model.getMaPhuKien()).delete())
//                                    .addOnCompleteListener(command -> sweetAlertDialog.dismiss());
//                        })
//                        .setCancelButton("Không,tôi nghĩ lại rồi:>", SweetAlertDialog::dismiss)
//                        .show();
//            }
//        });
        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Fragment fragment = new Fragment();
                    Class fragmentClass = Fragment_TTPK.class;
                    nphukien = model;
                    flag(1);
                    try {
                        fragment = (Fragment) fragmentClass.newInstance();

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    if (fragment != null) {
                        FragmentManager fragmentManager = context.getParentFragmentManager();
                        fragmentManager.beginTransaction().setCustomAnimations(android.R.animator.fade_in, android.R.animator.fade_out)
                                .replace(R.id.frameLayout, fragment).commit();
                    }
                }
            });
    }

    public void updatedata(List<phuKien> data) {
        data.clear();
        data.addAll(data);
        notifyDataSetChanged();
    }
    class myviewholder extends RecyclerView.ViewHolder
    {
        TextView name, price, sl;
        ImageView imageView;
        ProgressBar progressBar;
        LinearLayout linearLayout;
        public myviewholder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.itemTC_name);
            price = itemView.findViewById(R.id.itemTC_price);
            sl = (TextView) itemView.findViewById(R.id.itemTC_quantity);
            imageView = (ImageView) itemView.findViewById(R.id.itemTC_image);
            progressBar = itemView.findViewById(R.id.progress);
            linearLayout = itemView.findViewById(R.id.layout_TC);
        }
    }
}
