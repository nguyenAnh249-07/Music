package edu.hado.littleboss1.Model;

public class hoaDon {
    String maHD,maTV,ngayTao,nhanVien;

    public hoaDon(String maHD, String maTV, String ngayTao) {
        this.maHD = maHD;
        this.maTV = maTV;
        this.ngayTao = ngayTao;
    }

    public hoaDon(String maHD, String maTV, String ngayTao, String nhanVien) {
        this.maHD = maHD;
        this.maTV = maTV;
        this.ngayTao = ngayTao;
        this.nhanVien = nhanVien;
    }

    public hoaDon() {
    }

    public String getMaHD() {
        return maHD;
    }

    public void setMaHD(String maHD) {
        this.maHD = maHD;
    }

    public String getMaTV() {
        return maTV;
    }

    public void setMaTV(String maTV) {
        this.maTV = maTV;
    }

    public String getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(String ngayTao) {
        this.ngayTao = ngayTao;
    }

    public String getNhanVien() {
        return nhanVien;
    }

    public void setNhanVien(String nhanVien) {
        this.nhanVien = nhanVien;
    }
}
