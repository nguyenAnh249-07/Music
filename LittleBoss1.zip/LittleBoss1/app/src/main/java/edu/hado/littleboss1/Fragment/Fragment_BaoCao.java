package edu.hado.littleboss1.Fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import edu.hado.littleboss1.Adapter.adapterBaoCao;
import edu.hado.littleboss1.Model.baoCao;
import edu.hado.littleboss1.Model.hoaDon;
import edu.hado.littleboss1.Model.hoaDonChiTiet;
import edu.hado.littleboss1.R;


public class Fragment_BaoCao extends Fragment {

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("HoaDonChiTiet");
    DatabaseReference myRef1 = database.getReference("HoaDon");
    DatabaseReference myRef2 = database.getReference("ThanhVien");
    private List<hoaDonChiTiet> list = new ArrayList<>();
    private List<hoaDonChiTiet> lists = new ArrayList<>();
    private List<hoaDon> list1 = new ArrayList<>();
    private List<hoaDon> list01 = new ArrayList<>();
    private List<Integer> list2 = new ArrayList<>();

    private ArrayList<baoCao> listBaoCao = new ArrayList<>();
    private TextView tvTongTien, tvKhachHang, tuNgay, denNgay;

    private RecyclerView recyclerView;

    public Fragment_BaoCao() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment__bao_cao, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        tvTongTien = view.findViewById(R.id.tv_tongtien);
        tvKhachHang = view.findViewById(R.id.tv_khachhang);
        tuNgay = view.findViewById(R.id.edt_tungay);
        denNgay = view.findViewById(R.id.edt_denngay);
        recyclerView = view.findViewById(R.id.rcv_baocao);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    list.clear();
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                        for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                            hoaDonChiTiet hoaDonChiTiet = dataSnapshot1.getValue(edu.hado.littleboss1.Model.hoaDonChiTiet.class);
                            list.add(hoaDonChiTiet);
                        }
                    }
                    //laasy ngay hien tai
                    long millis = System.currentTimeMillis();
                    String date = android.text.format.DateFormat.format("dd/MM/yyyy", new Date(millis)).toString();
                    double tongtien = 0;
                    String fomat = "dd/MM/yyyy";
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(fomat);
                    for (int i = 0; i < list.size(); i++) {
                        if (simpleDateFormat.format(Long.parseLong(list.get(i).getMaHD())).equals(date)) {
                            Log.d("hieudeptrai", "onDataChange: " + list.get(i).getMaHD());
                            tongtien += Double.parseDouble(list.get(i).getTongTien());
                        }
                    }
                    DecimalFormat decimalFormat = (DecimalFormat) NumberFormat.getInstance(Locale.US);
                    decimalFormat.applyPattern("#,###,###,###");
                    String format = decimalFormat.format(tongtien);
                    tvTongTien.setText(format + " VNĐ");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        myRef1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    list1.clear();
                    list2.clear();
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                        hoaDon hoaDon = dataSnapshot.getValue(edu.hado.littleboss1.Model.hoaDon.class);
                        list1.add(hoaDon);
                    }
                    for (int i = 0; i < list1.size(); i++) {
                        //điếm maTV trùng nhau để lấy số lượng khách hàng mua hàng
                        int dem = 0;
                        for (int j = 0; j < list1.size(); j++) {
                            if (list1.get(i).getMaTV().equals(list1.get(j).getMaTV())) {
                                dem++;
                            }
                        }
                        list2.add(dem);
                    }
                    int max = list2.get(0);
                    for (int i = 0; i < list2.size(); i++) {
                        //lấy ra số lượng khách hàng mua hàng nhiều nhất
                        if (max < list2.get(i)) {
                            max = list2.get(i);
                        }
                    }
                    for (int i = 0; i < list2.size(); i++) {
                        //lấy ra mã khách hàng mua hàng nhiều nhất
                        if (max == list2.get(i)) {
                            int finalI = i;
                            myRef2.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    if (snapshot.exists()) {
                                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                                            if (dataSnapshot.getKey().equals(list1.get(finalI).getMaTV())) {
                                                tvKhachHang.setText("Tên : " + dataSnapshot.getValue(edu.hado.littleboss1.Model.thanhVien.class).getHoTen() + "\nSố điện thoại : " + dataSnapshot.getValue(edu.hado.littleboss1.Model.thanhVien.class).getSoDienThoai());
                                            }
                                        }
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });
                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        tuNgay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MaterialDatePicker.Builder builder = MaterialDatePicker.Builder.datePicker();
                builder.setTitleText("Chọn ngày");
                MaterialDatePicker materialDatePicker = builder.build();
                materialDatePicker.show(getParentFragmentManager(), "DATE_PICKER");
                materialDatePicker.addOnPositiveButtonClickListener(selection -> {
                    String format = "dd/MM/yyyy";
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
                    tuNgay.setText(simpleDateFormat.format(materialDatePicker.getSelection()));

                    denNgay.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            MaterialDatePicker.Builder builder = MaterialDatePicker.Builder.datePicker();
                            builder.setTitleText("Chọn ngày");
                            MaterialDatePicker materialDatePicker = builder.build();
                            materialDatePicker.show(getParentFragmentManager(), "DATE_PICKER");
                            materialDatePicker.addOnPositiveButtonClickListener(selection -> {
                                String format = "dd/MM/yyyy";
                                SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
                                denNgay.setText(simpleDateFormat.format(materialDatePicker.getSelection()));
                                myRef.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                        if (snapshot.exists()) {
                                            list.clear();
                                            lists.clear();
                                            listBaoCao.clear();
                                            for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                                                for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                                                    hoaDonChiTiet hoaDonChiTiet = dataSnapshot1.getValue(edu.hado.littleboss1.Model.hoaDonChiTiet.class);
                                                    list.add(hoaDonChiTiet);
                                                }
                                            }
                                            String tungay = tuNgay.getText().toString();
                                            String denngay = denNgay.getText().toString();
                                            String fomat = "dd/MM/yyyy";
                                            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(fomat);
                                            //lọc ra các hóa đơn trong khoảng thời gian
                                            for (int i = 0; i < list.size(); i++) {
                                                String maHD = simpleDateFormat.format(Long.parseLong(list.get(i).getMaHD()));
                                                if (maHD.compareTo(tungay) >= 0 && maHD.compareTo(denngay) <= 0) {
                                                    lists.add(list.get(i));
                                                }
                                            }
                                            Map<String, Double> sumByDate = new HashMap<>();

                                            for (hoaDonChiTiet item : lists) {
                                                String currentDate = simpleDateFormat.format(Long.parseLong(item.getMaHD()));
                                                double currentTongTien = Double.parseDouble(item.getTongTien());

                                                if (sumByDate.containsKey(currentDate)) {
                                                    // If the date already exists in the map, update the sum
                                                    double sum = sumByDate.get(currentDate) + currentTongTien;
                                                    sumByDate.put(currentDate, sum);
                                                } else {
                                                    // If the date doesn't exist in the map, add a new entry
                                                    sumByDate.put(currentDate, currentTongTien);
                                                }
                                            }

                                            List<baoCao> finalListBaoCao = new ArrayList<>();

                                            for (Map.Entry<String, Double> entry : sumByDate.entrySet()) {
                                                String date = entry.getKey();
                                                double sum = entry.getValue();
                                                DecimalFormat decimalFormat = (DecimalFormat) NumberFormat.getInstance(Locale.US);
                                                decimalFormat.applyPattern("#,###,###,###");
                                                String formattedSum = decimalFormat.format(sum);
                                                finalListBaoCao.add(new baoCao(date, formattedSum));
                                            }
                                            adapterBaoCao adapterbaocao = new adapterBaoCao(getContext(), finalListBaoCao);
                                            recyclerView.setAdapter(adapterbaocao);
                                            recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {

                                    }
                                });
                            });
                        }
                    });

                });

            }
        });


    }

}