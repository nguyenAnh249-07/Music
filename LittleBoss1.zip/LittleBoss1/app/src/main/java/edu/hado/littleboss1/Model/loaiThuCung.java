package edu.hado.littleboss1.Model;

public class loaiThuCung {
    private String loaiThuCung,maThuCung;

    public loaiThuCung(String loaiThuCung, String maThuCung) {
        this.loaiThuCung = loaiThuCung;
        this.maThuCung = maThuCung;
    }

    public loaiThuCung() {
    }

    public String getLoaiThuCung() {
        return loaiThuCung;
    }

    public void setLoaiThuCung(String loaiThuCung) {
        this.loaiThuCung = loaiThuCung;
    }

    public String getMaThuCung() {
        return maThuCung;
    }

    public void setMaThuCung(String maThuCung) {
        this.maThuCung = maThuCung;
    }
}
