package edu.hado.littleboss1.Fragment;

import static android.app.Activity.RESULT_OK;
import static edu.hado.littleboss1.Adapter.adapterFirebaseTC.nthuCung;
import static edu.hado.littleboss1.Adapter.adapterLoadTC.n2thuCung;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import org.angmarch.views.NiceSpinner;
import org.angmarch.views.OnSpinnerItemSelectedListener;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import cn.pedant.SweetAlert.SweetAlertDialog;
import edu.hado.littleboss1.Model.CustomFormat;
import edu.hado.littleboss1.Model.loaiThuCung;
import edu.hado.littleboss1.Model.thuCung;
import edu.hado.littleboss1.R;

public class Fragment_TTTC extends Fragment {
    private Button confirm, cancel;
    private TextInputLayout name, species, quantity, price, description;
    private TextView date;
    private RadioGroup character;
    private RadioButton male, female;
    private NiceSpinner spinner;
    private ImageView image;
    private Button edit, delete,addimg;
    private ProgressBar progressBar;
    private Boolean click = false;
    private Boolean spinerClick = false;
    private ArrayList<loaiThuCung> loaiThuCungs;
    private CustomFormat customFormat;
    private Uri imageUri = null;
    private String im;
    private int item;
    private boolean checkimg = false;
    private FirebaseDatabase rootNode;
    private DatabaseReference reference;
    private String id;
    private thuCung mthuCung;
    public static int id3;
    private int year, month, day;
    SweetAlertDialog pDialog;
    public Fragment_TTTC() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment__t_t_t_c, container, false);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        confirm = view.findViewById(R.id.add_confirm);
        cancel = view.findViewById(R.id.add_cancel);
        name = view.findViewById(R.id.edt_name);
        date = view.findViewById(R.id.edt_date);
        species = view.findViewById(R.id.edt_species);
        quantity = view.findViewById(R.id.edt_quantity);
        price = view.findViewById(R.id.edt_price);
        description = view.findViewById(R.id.edt_description);
        character = view.findViewById(R.id.radioGroup_character);
        male = view.findViewById(R.id.radioButton_male);
        female = view.findViewById(R.id.radioButton_female);
        spinner = view.findViewById(R.id.nice_spinner);
        image = view.findViewById(R.id.imview);
        delete = view.findViewById(R.id.btn_xoaTC);
        edit = view.findViewById(R.id.btn_suaTC);
        progressBar = view.findViewById(R.id.progress);
        addimg = view.findViewById(R.id.addimg);
        price.getEditText().addTextChangedListener(customFormat= new CustomFormat(price));
        progressBar.setVisibility(View.GONE);
        delete.setOnClickListener(this::onClickDelete);
        edit.setOnClickListener(this::onClickEdit);
        cancel.setOnClickListener(this::onClickCancel);
        confirm.setOnClickListener(this::onClickConfirm);
        addimg.setOnClickListener(this::onImageClick);
        date.setOnClickListener(this::onDateClick);
        spinner.setOnClickListener(this::onClickSpinner);
        rootNode = FirebaseDatabase.getInstance();
        reference = rootNode.getReference("ThuCung");
        loaiThuCungs = new ArrayList<>();
        switch(id3){
            case 1:{
                mthuCung = n2thuCung;
                break;
            }
            case 2:{
                mthuCung = nthuCung;
                break;
            }
        }
        id = mthuCung.getMaThuCung();
        loadTl();
        fillData();
    }

    private void onClickSpinner(View view) {
        spinerClick = true;
    }

    private void onDateClick(View view) {
        final Calendar calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);
        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog datePickerDialog = new DatePickerDialog(requireActivity(), new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month += 1;
                date.setText(dayOfMonth + "/" + month + "/" + year);
            }
        }, year, month, day);
        datePickerDialog.show();
    }
    private void onClickConfirm(View view) {
        //validate
        if(!validatename() | !validateDate() | !validatePrice() | !validatesex() | !validateSpecies() |!validateQuantity()){
            return;
        }
        if(!spinerClick){
            new SweetAlertDialog(requireContext(), SweetAlertDialog.WARNING_TYPE)
                    .setTitleText("Hình như bạn chưa sửa loại thú cưng hãy kiểm tra kĩ một lần nữa")
                    .show();
            spinerClick = false;
            return;
        }
        showProgress();
        String _name = name.getEditText().getText().toString().trim();
        String _date = date.getText().toString().trim();
        String _species = species.getEditText().getText().toString().trim();
        String _quantity = quantity.getEditText().getText().toString().trim();
        String _price = price.getEditText().getText().toString().trim();
        String _description = description.getEditText().getText().toString().trim();
        String sex;
        if (male.isChecked()) {
            sex = "Đực";
        } else {
            sex = "Cái";
        }
        String ma = loaiThuCungs.get(item).getMaThuCung();

//        if(checkimg){
//            uploadimg();
//            checkimg = false;
//        }
        if(im==null){
            im = mthuCung.getHinh();
        }
        thuCung thuCung1 = new thuCung(_name,id,ma,sex,_date,_species,_description,im,_price,Integer.parseInt(_quantity));
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put(id,thuCung1);
        reference.updateChildren(hashMap).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                pDialog.dismissWithAnimation();
                Toast.makeText(requireContext(), "Cập nhật thành công", Toast.LENGTH_SHORT).show();
                callFragment();
            }
        });

    }
    //onclick image
    private void onImageClick(View view) {
        checkimg = true;
        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
        pick.setType("image/*");
//        Intent pho = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        Intent chosser = Intent.createChooser(pick, "chon");
//        chosser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{pho});
        startActivityForResult(chosser, 999);
    }
    //showprogress
    private void showProgress(){
        pDialog = new SweetAlertDialog(requireContext(), SweetAlertDialog.PROGRESS_TYPE);
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#A5DC86"));
        pDialog.setTitleText("Đang tải dữ liệu lên...");
        pDialog.setCancelable(false);
        pDialog.show();
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 999 && resultCode == RESULT_OK) {
            if (data.getExtras() != null) {

                Bitmap bitmap = (Bitmap) data.getExtras().get("data");
                image.setImageBitmap(bitmap);
                imageUri = data.getData();
                uploadimg();
                System.out.println(imageUri);
                mthuCung.setHinh(String.valueOf(imageUri));

            } else {
                imageUri = data.getData();
                uploadimg();
                mthuCung.setHinh(String.valueOf(imageUri));
                try {
                    InputStream inputStream = requireActivity().getContentResolver().openInputStream(imageUri);
                    imageUri = Uri.parse(inputStream.toString());
                    System.out.println(imageUri);
                    Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                    image.setImageBitmap(bitmap);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    //uploadimg
    private void uploadimg(){
        showProgress();
        pDialog.setTitleText("Đang tải hình ảnh ...");
        String filepath = "ImagePet/"+id;
        StorageReference storageReference = FirebaseStorage.getInstance().getReference(filepath);
        storageReference.putFile(imageUri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        Log.d("Upload","onSuccess");
                        Task<Uri> uriTask = taskSnapshot.getStorage().getDownloadUrl();
                        while (!uriTask.isSuccessful());
                        String uploadimg = ""+uriTask.getResult();
//                        updateimg(uploadimg);
                            im = uploadimg;
                            pDialog.dismissWithAnimation();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                });
    }
    private void onClickCancel(View view) {
        // Create a storage reference from our app
        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference storageRef = storage.getReference();

// Create a reference to the file to delete
        StorageReference desertRef = storageRef.child("ImagePK/"+id);

// Delete the file
        desertRef.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                // File deleted successfully
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                // Uh-oh, an error occurred!
            }
        });
        callFragment();
    }

    private void onClickDelete(View view) {
        DatabaseReference reference;
        reference = FirebaseDatabase.getInstance().getReference("ThuCung");
        new SweetAlertDialog(requireContext(), SweetAlertDialog.WARNING_TYPE)
                .setTitleText("Bạn chắc chứ?")
                .setContentText("Sẽ không thể khôi phục dữ liệu này!")
                .setConfirmButton("Có,tôi muốn xóa nó!", sweetAlertDialog -> {
                    reference.child(mthuCung.getMaThuCung()).removeValue()
                            .addOnCompleteListener(command -> sweetAlertDialog.dismiss())
                            .addOnCompleteListener(command -> callFragment())
                            .addOnCompleteListener(command -> Toast.makeText(requireContext(), "Xóa Thành Công", Toast.LENGTH_SHORT).show());

                })
                .setCancelButton("Không,tôi nghĩ lại rồi:>", SweetAlertDialog::dismiss)
                .show();
    }

    private void callFragment() {
        Fragment fragment = new Fragment();
        Class fragmentClass = Fragment_ThuCung.class;
        try {
            fragment = (Fragment) fragmentClass.newInstance();

        } catch (Exception e) {
            e.printStackTrace();
        }
        if (fragment != null) {
            FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();
            fragmentManager.beginTransaction().setCustomAnimations(android.R.animator.fade_in, android.R.animator.fade_out)
                    .replace(R.id.frameLayout, fragment).commit();
        }
    }

    private void onClickEdit(View view) {
        click = true;
        loadTl();
        progressBar.setVisibility(View.VISIBLE);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                name.setEnabled(true);
                date.setEnabled(true);
                species.setEnabled(true);
                quantity.setEnabled(true);
                price.setEnabled(true);
                description.setEnabled(true);
                male.setEnabled(true);
                female.setEnabled(true);
                spinner.setEnabled(true);
                confirm.setVisibility(View.VISIBLE);
                progressBar.setVisibility(View.GONE);
                addimg.setVisibility(View.VISIBLE);
            }
        }, 2000);
    }

    private void fillData() {
        name.setEnabled(false);
        name.getEditText().setText(mthuCung.getTenThuCung());
        date.setText(mthuCung.getNgaySinh());
        date.setEnabled(false);
        species.getEditText().setText(mthuCung.getGiongLoai());
        species.setEnabled(false);
        quantity.getEditText().setText(mthuCung.getSoLuong() + "");
        quantity.setEnabled(false);
        price.getEditText().setText(mthuCung.getGia());
        price.setEnabled(false);
        description.getEditText().setText(mthuCung.getMoTa());
        description.setEnabled(false);
        if (mthuCung.getGioiTinh().equalsIgnoreCase("Đực")) {
            male.setChecked(true);
        } else
            female.setChecked(true);
        male.setEnabled(false);
        female.setEnabled(false);
        spinner.setEnabled(false);

        if(mthuCung.getHinh() == null){
            image.setImageResource(R.drawable.addimg);
        }
        else{
            Glide.with(requireContext()).load(mthuCung.getHinh()).into(image);
        }
        confirm.setVisibility(View.GONE);
        addimg.setVisibility(View.GONE);
    }

    //load loại thú cưng
    private void loadTl() {
        DatabaseReference reference;
        reference = FirebaseDatabase.getInstance().getReference("LoaiThuCung");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                loaiThuCungs.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    loaiThuCung thuCung = dataSnapshot.getValue(loaiThuCung.class);
                    loaiThuCungs.add(thuCung);
                    System.out.println(loaiThuCungs.size());
                }
                if (click) {
                    List<String> dataset = new ArrayList<>();
                    for (int i = 0; i < loaiThuCungs.size(); i++) {
                        System.out.println(loaiThuCungs.get(i).getLoaiThuCung());
                        dataset.add(loaiThuCungs.get(i).getLoaiThuCung());
                    }
                    spinner.attachDataSource(dataset);
                    spinner.setOnSpinnerItemSelectedListener(new OnSpinnerItemSelectedListener() {
                        @Override
                        public void onItemSelected(NiceSpinner parent, View view, int position, long id) {
                            // This example uses String, but your type can be any
                            item = position;

                        }
                    });
                } else {
                    for (int i = 0; i < loaiThuCungs.size(); i++) {
                        if (loaiThuCungs.get(i).getMaThuCung().equals(mthuCung.getMaLoaiThuCung())) {
                            spinner.setText(loaiThuCungs.get(i).getLoaiThuCung());
                            return;
                        }
                    }


                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    //valivalidate

    private boolean validatesex() {
        if (character.getCheckedRadioButtonId() == -1) {
            Toast.makeText(requireActivity(), "Bạn chưa chọn giới tính! Hãy chọn giới tính đi !!! ", Toast.LENGTH_SHORT).show();
            return false;
        } else
            return true;
    }

    private boolean validatename() {
        String _name = name.getEditText().getText().toString().trim();
        if (_name.isEmpty()) {
            name.setError("Không được bỏ trống!");
            name.requestFocus();
            return false;
        } else if (_name.length() > 16) {
            name.setError(("Tên quá dài!"));
            return false;
        } else {
            name.setError(null);
            name.setErrorEnabled(false);
            return true;
        }
    }

    private boolean validateDate() {
        SimpleDateFormat dft=new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        String _date = date.getText().toString().trim();
        if (_date.isEmpty()) {
            date.setError("Không được bỏ trống!");
            date.requestFocus();
            return false;
        }
        else
            date.setError(null);
        return true;
    }

    private boolean validateSpecies() {
        String _species = species.getEditText().getText().toString().trim();
        if (_species.isEmpty()) {
            species.setError("Không được bỏ trống!");
            species.requestFocus();
            return false;
        } else
            species.setError(null);
        species.setErrorEnabled(false);
        return true;
    }

    private boolean validateQuantity() {
        String _quantity = quantity.getEditText().getText().toString().trim();
        if (_quantity.isEmpty()) {
            quantity.setError("Không được bỏ trống!");
            quantity.requestFocus();
            return false;
        }else if(_quantity.length() > 8) {
            price.setError("Số quá lớn!");
            return false;
        }else
            quantity.setError(null);
        quantity.setErrorEnabled(false);
        return true;
    }
    private boolean validatePrice() {
        String _price = price.getEditText().getText().toString().trim();
        if (_price.isEmpty()) {
            price.setError("Không được bỏ trống!");
            price.requestFocus();
            return false;
        }else if(_price.length() > 18){
            price.setError("Số quá lớn!");
            return false;
        }
        else
            price.setError(null);
        price.setErrorEnabled(false);
        return true;
    }
}