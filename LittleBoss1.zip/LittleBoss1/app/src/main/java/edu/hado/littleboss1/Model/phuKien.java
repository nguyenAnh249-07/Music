package edu.hado.littleboss1.Model;

public class phuKien {
    private String maPhuKien,maLoaiThuCung,tenPhuKien,hinh,moTa,gia;
    private int soluong;

    public phuKien(String maPhuKien, String maLoaiThuCung, String tenPhuKien, String hinh, String moTa, String gia, int soluong) {
        this.maPhuKien = maPhuKien;
        this.maLoaiThuCung = maLoaiThuCung;
        this.tenPhuKien = tenPhuKien;
        this.hinh = hinh;
        this.moTa = moTa;
        this.gia = gia;
        this.soluong = soluong;
    }

    public phuKien() {
    }

    public String getMaPhuKien() {
        return maPhuKien;
    }

    public void setMaPhuKien(String maPhuKien) {
        this.maPhuKien = maPhuKien;
    }

    public String getMaLoaiThuCung() {
        return maLoaiThuCung;
    }

    public void setMaLoaiThuCung(String maLoaiThuCung) {
        this.maLoaiThuCung = maLoaiThuCung;
    }

    public String getTenPhuKien() {
        return tenPhuKien;
    }

    public void setTenPhuKien(String tenPhuKien) {
        this.tenPhuKien = tenPhuKien;
    }

    public String getHinh() {
        return hinh;
    }

    public void setHinh(String hinh) {
        this.hinh = hinh;
    }

    public String getMoTa() {
        return moTa;
    }

    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }

    public String getGia() {
        return gia;
    }

    public void setGia(String gia) {
        this.gia = gia;
    }

    public int getSoluong() {
        return soluong;
    }

    public void setSoluong(int soluong) {
        this.soluong = soluong;
    }
}
