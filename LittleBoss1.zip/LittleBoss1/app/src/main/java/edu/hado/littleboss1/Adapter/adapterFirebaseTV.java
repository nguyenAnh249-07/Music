package edu.hado.littleboss1.Adapter;


import static edu.hado.littleboss1.Fragment.Fragment_ThanhVien.maTV;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

import java.util.ArrayList;
import java.util.List;

import edu.hado.littleboss1.Fragment.Fragment_ThanhVien;
import edu.hado.littleboss1.Fragment.Fragment_hoaDonThanhVien;
import edu.hado.littleboss1.Model.phuKien;
import edu.hado.littleboss1.Model.thanhVien;
import edu.hado.littleboss1.R;

public class adapterFirebaseTV extends FirebaseRecyclerAdapter<thanhVien, adapterFirebaseTV.myviewholder>
{
    Fragment_ThanhVien context;
    public ArrayList<thanhVien> thanhviens;


    public adapterFirebaseTV(@NonNull FirebaseRecyclerOptions<thanhVien> options , Fragment_ThanhVien thanhvien, ArrayList<thanhVien> mthanhvienss) {
        super(options);
        this.context = thanhvien;
        this.thanhviens = mthanhvienss;
    }

    @NonNull
    @Override
    public myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_thanh_vien,parent,false);
        return new myviewholder(view);
    }

    @Override
    protected void onBindViewHolder(@NonNull myviewholder holder, @SuppressLint("RecyclerView") int position, @NonNull thanhVien model) {
        holder.name.setText(model.getHoTen());
        holder.sdt.setText(model.getSoDienThoai());
        holder.layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment fragment = new Fragment();
                Class fragmentClass = Fragment_hoaDonThanhVien.class;
                maTV = model.getMaTV();
                try {
                    fragment = (Fragment) fragmentClass.newInstance();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (fragment != null) {
                    FragmentManager fragmentManager =context.getParentFragmentManager() ;
                    fragmentManager.beginTransaction().setCustomAnimations(android.R.animator.fade_in, android.R.animator.fade_out)
                            .replace(R.id.frameLayout, fragment).commit();
                }
            }
        });
    }

    public void updatedata(List<phuKien> data) {
        data.clear();
        data.addAll(data);
        notifyDataSetChanged();
    }
    class myviewholder extends RecyclerView.ViewHolder
    {
        TextView name,sdt;
        RelativeLayout layout;
        public myviewholder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.name);
            sdt = itemView.findViewById(R.id.sdt);
            layout = itemView.findViewById(R.id.clicktv);
        }
    }
}
