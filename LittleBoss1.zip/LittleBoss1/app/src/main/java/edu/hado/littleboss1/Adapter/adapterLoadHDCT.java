package edu.hado.littleboss1.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import edu.hado.littleboss1.Fragment.Fragment_hoaDonChiTiet;
import edu.hado.littleboss1.Model.hoaDonCT;
import edu.hado.littleboss1.Model.loaiThuCung;
import edu.hado.littleboss1.R;

public class adapterLoadHDCT  extends RecyclerView.Adapter<adapterLoadHDCT.ViewHolder> {
    Context context;
    ArrayList<hoaDonCT> hoaDonCTs;
    Fragment_hoaDonChiTiet Fragment_hoaDonChiTiet;
    public adapterLoadHDCT(Fragment_hoaDonChiTiet Fragment_hoaDonChiTiet, ArrayList<hoaDonCT> hoaDonCTs, Context context) {
        this.Fragment_hoaDonChiTiet = Fragment_hoaDonChiTiet;
        this.hoaDonCTs = hoaDonCTs;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.item_hdct, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") final int position) {

        hoaDonCT donCT = hoaDonCTs.get(position);
        DecimalFormat df = new DecimalFormat("#,###");
        holder.name.setText(donCT.getTen());
        holder.sl.setText("x"+donCT.getSl());
        holder.gia.setText(Html.fromHtml(df.format(Double.parseDouble(donCT.getGia()))+"<sup><small>₫</small></sup>"));
        Glide.with(context)
                .load(donCT.getHinh())
                .into(holder.imageView);
    }

    public void updatedata(List<loaiThuCung> data) {
        data.clear();
        data.addAll(data);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return hoaDonCTs.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name,sl,gia;
        ImageView imageView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.tensp);
            sl = itemView.findViewById(R.id.slsp);
            gia = itemView.findViewById(R.id.giasp);
            imageView = itemView.findViewById(R.id.avt);
        }
    }
}
