package edu.hado.littleboss1.Adapter;

import static edu.hado.littleboss1.Fragment.Fragment_TTTC.id3;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerOptions;

import java.util.ArrayList;
import java.util.List;

import edu.hado.littleboss1.Fragment.Fragment_TTTC;
import edu.hado.littleboss1.Fragment.Fragment_ThuCung;
import edu.hado.littleboss1.Model.CustomFormat;
import edu.hado.littleboss1.Model.thuCung;
import edu.hado.littleboss1.R;

public class adapterLoadTC  extends RecyclerView.Adapter<adapterLoadTC.ViewHolder> {
    Context context;
    Fragment_ThuCung fragment_thuCung;
    public ArrayList<thuCung> ThuCungs;
    thuCung mthuCung;
    FirebaseRecyclerOptions<thuCung> options;
    private CustomFormat customFormat;
    public static thuCung n2thuCung = new thuCung();
    LayoutInflater inflater;


    public adapterLoadTC(Context context, ArrayList<thuCung> thuCungs,Fragment_ThuCung fragment_thuCung) {
        this.context = context;
        this.fragment_thuCung = fragment_thuCung;
        ThuCungs = thuCungs;
        this.inflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.item_thu_cung, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView")final int position) {
        mthuCung = ThuCungs.get(position);

        holder.name.setText(mthuCung.getTenThuCung());
        holder.price.setText(Html.fromHtml(mthuCung.getGia()+"<sup><small>₫</small></sup>"));
        holder.sl.setText(""+mthuCung.getSoLuong());
        holder.progressBar.setVisibility(View.VISIBLE);
        Glide.with(context)
                .load(mthuCung.getHinh())
                .into(holder.imageView);
        holder.progressBar.setVisibility(View.GONE);

        holder.linearLayout.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment fragment = new Fragment();
                Class fragmentClass = Fragment_TTTC.class;
                n2thuCung = ThuCungs.get(position);
                id3 = 1;
                try {
                    fragment = (Fragment) fragmentClass.newInstance();

                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (fragment != null) {
                    FragmentManager fragmentManager = fragment_thuCung.getParentFragmentManager();
                    fragmentManager.beginTransaction().setCustomAnimations(android.R.animator.fade_in, android.R.animator.fade_out)
                            .replace(R.id.frameLayout, fragment).commit();
                }
            }
        });
    }

    public void updatedata(List<thuCung> data) {
        data.clear();
        data.addAll(data);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return ThuCungs.size();
    }



    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, price, sl;
        ImageView imageView;
        ProgressBar progressBar;
        LinearLayout linearLayout;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.itemTC_name);
            price = itemView.findViewById(R.id.itemTC_price);
            sl = (TextView) itemView.findViewById(R.id.itemTC_quantity);
            imageView = (ImageView) itemView.findViewById(R.id.itemTC_image);
            progressBar = itemView.findViewById(R.id.progress);
            linearLayout = itemView.findViewById(R.id.layout_TC);
        }
    }
}
