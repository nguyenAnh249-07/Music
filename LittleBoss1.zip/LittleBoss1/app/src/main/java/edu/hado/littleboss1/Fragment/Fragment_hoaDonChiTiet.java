package edu.hado.littleboss1.Fragment;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.DecimalFormat;
import java.util.ArrayList;

import cn.pedant.SweetAlert.SweetAlertDialog;
import edu.hado.littleboss1.Activity.MainActivity;
import edu.hado.littleboss1.Adapter.adapterLoadHDCT;
import edu.hado.littleboss1.Model.hoaDonCT;
import edu.hado.littleboss1.Model.hoaDonChiTiet;
import edu.hado.littleboss1.Model.phuKien;
import edu.hado.littleboss1.Model.thuCung;
import edu.hado.littleboss1.R;

public class Fragment_hoaDonChiTiet extends Fragment {
    private RecyclerView recyclerView;
    private TextView textView;
    private ArrayList<hoaDonCT> hoaDonCTS;
    private ArrayList<hoaDonChiTiet> hoaDonCTietS = new ArrayList<>();
    private ArrayList<phuKien> phukiens = new ArrayList<>();
    private ArrayList<thuCung> thuCungs = new ArrayList<>();
    private adapterLoadHDCT adapterloadHDCT;
    private MainActivity activity;
    public static String maHD;
    SweetAlertDialog pDialog;

    public Fragment_hoaDonChiTiet() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_hoa_don_chi_tiet, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = view.findViewById(R.id.rc_hd);
        textView = view.findViewById(R.id.tt);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager llm = new LinearLayoutManager(requireActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(llm);
        hoaDonCTS = new ArrayList<>();
        activity = (MainActivity) getActivity();
        showProgress();
        loadHD();


    }


    private void listHD(hoaDonCT donCT){
        hoaDonCTS.add(donCT);
        adapterloadHDCT = new adapterLoadHDCT(Fragment_hoaDonChiTiet.this,hoaDonCTS,activity);
        recyclerView.setAdapter(adapterloadHDCT);
        pDialog.dismissWithAnimation();
        DecimalFormat df = new DecimalFormat("#,###");
        double fee = 0;
        for(int i = 0 ; i < hoaDonCTS.size() ; i++){
            fee += Double.parseDouble(hoaDonCTS.get(i).getGia());
            textView.setText("Tổng Tiền : "+Html.fromHtml(df.format(fee)+"<sup><small>₫</small></sup>"));
        }
    }

    //loadHD
    private void loadHD() {
        DatabaseReference check = FirebaseDatabase.getInstance().getReference("HoaDonChiTiet");
        hoaDonCTietS.clear();
        check.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot x : snapshot.getChildren()) {
                    Query check = FirebaseDatabase.getInstance().getReference("HoaDonChiTiet").child(x.getKey()).orderByChild("maHD").equalTo(maHD);
                    check.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            for (DataSnapshot x : snapshot.getChildren()
                            ) {
                                hoaDonChiTiet donChiTiet = x.getValue(hoaDonChiTiet.class);
                                hoaDonCTietS.add(donChiTiet);
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }
                loadPK(hoaDonCTietS);
                loadTC(hoaDonCTietS);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    //progress
    private void showProgress() {
        pDialog = new SweetAlertDialog(requireContext(), SweetAlertDialog.PROGRESS_TYPE);
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#A5DC86"));
        pDialog.setTitleText("Loading");
        pDialog.setCancelable(false);
        pDialog.show();
    }

    //loadPK
    private void loadPK(ArrayList<hoaDonChiTiet> list) {
        DatabaseReference reference;
        reference = FirebaseDatabase.getInstance().getReference("PhuKien");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                phukiens.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    phuKien thuCung = dataSnapshot.getValue(phuKien.class);
                    phukiens.add(thuCung);
                }
                if (list.size() > 0) {
                    for (int i = 0; i < list.size(); i++) {
                        if (list.get(i).getMaPK() != null) {
                            for(int j = 0 ; j < phukiens.size() ; j++){
                                if (list.get(i).getMaPK().equals(phukiens.get(j).getMaPhuKien())) {
                                    hoaDonCT donCT = new hoaDonCT();
                                    donCT.setTen(phukiens.get(j).getTenPhuKien());
                                    donCT.setGia(String.valueOf(Double.parseDouble(phukiens.get(j).getGia().replaceAll("[^\\d]", "")) * list.get(i).getsLPK()));
                                    donCT.setSl(list.get(i).getsLPK());
                                    donCT.setHinh(phukiens.get(j).getHinh());
                                    listHD(donCT);
                                }
                            }
                        }

                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    // load thú cưng
    private void loadTC(ArrayList<hoaDonChiTiet> list) {
        DatabaseReference reference;
        reference = FirebaseDatabase.getInstance().getReference("ThuCung");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                thuCungs.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    thuCung thuCung = dataSnapshot.getValue(thuCung.class);
                    thuCungs.add(thuCung);
                }
                if (list.size() > 0) {
                    for (int i = 0; i < list.size(); i++) {
                        if (list.get(i).getMaTC() != null) {
                            for(int j = 0 ; j < thuCungs.size() ; j++){
                                if (list.get(i).getMaTC().equals(thuCungs.get(j).getMaThuCung())) {
                                    hoaDonCT donCT = new hoaDonCT();
                                    donCT.setTen(thuCungs.get(j).getTenThuCung());
                                    donCT.setGia(String.valueOf(Double.parseDouble(thuCungs.get(j).getGia().replaceAll("[^\\d]", "")) * list.get(i).getsLTC()));
                                    donCT.setSl(list.get(i).getsLTC());
                                    donCT.setHinh(thuCungs.get(j).getHinh());
                                    listHD(donCT);
                                }
                            }
                        }

                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}